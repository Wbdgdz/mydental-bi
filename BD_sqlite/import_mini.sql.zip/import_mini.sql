/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.6.2-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: mydentalv2
-- ------------------------------------------------------
-- Server version	11.6.2-MariaDB-ubu2404

CREATE DATABASE IF NOT EXISTS kbmdocv2;
GRANT ALL PRIVILEGES ON kbmdocv2.* TO 'root'@'%';
FLUSH PRIVILEGES;
-- Sélectionner la base de données
USE kbmdocv2;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `BI_users`
--

CREATE TABLE BI_users (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
);
INSERT INTO BI_users(username, password) VALUES ('admin', '$2b$10$e1TibLgMVqUdiTYYTQCHCu7OiO0CgGXn7uX693HsHEByZ.V475AVi');
--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lot_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `qte` int(11) DEFAULT NULL,
  `productPrice` double DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `remaining_amount` double DEFAULT NULL,
  `action_date` datetime DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_47CC8C92A8CBA5F7` (`lot_id`),
  KEY `IDX_47CC8C924584665A` (`product_id`),
  KEY `IDX_47CC8C92A76ED395` (`user_id`),
  KEY `IDX_47CC8C9287F4FB17` (`doctor_id`),
  KEY `IDX_47CC8C926B899279` (`patient_id`),
  KEY `IDX_47CC8C922989F1FD` (`invoice_id`),
  FOREIGN KEY (`invoice_id`) REFERENCES`invoice` (`id`),
  FOREIGN KEY (`product_id`) REFERENCES`product` (`id`),
  FOREIGN KEY (`patient_id`) REFERENCES`patient` (`id`),
  FOREIGN KEY (`doctor_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`lot_id`) REFERENCES`lot` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autocomplete`
--

DROP TABLE IF EXISTS `autocomplete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autocomplete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code1` varchar(155) DEFAULT NULL,
  `code2` varchar(155) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `description1` longtext DEFAULT NULL,
  `description2` longtext DEFAULT NULL,
  `description3` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=647 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autocomplete`
--

LOCK TABLES `autocomplete` WRITE;
/*!40000 ALTER TABLE `autocomplete` DISABLE KEYS */;
INSERT INTO `autocomplete` VALUES
(1,'058','0','Abachi (poussière de bois)','Allergie',NULL,NULL),
(2,'058','0','Abeille','Allergie',NULL,NULL),
(3,'058','0','Abricot','Allergie',NULL,NULL),
(4,'058','0','Absinthe','Allergie',NULL,NULL),
(5,'058','0','Acarus siro','Allergie',NULL,NULL),
(643,'066',NULL,'curettage','caractéristiques','0','0'),
(644,'066',NULL,'endo trt durgence','caractéristiques','0','0'),
(645,'066',NULL,'refuser exo necessite endo fracture instr autre','caractéristiques','0','0'),
(646,'066',NULL,'endo 21(drainage intracanallaire)','caractéristiques','0','0');
/*!40000 ALTER TABLE `autocomplete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup`
--

DROP TABLE IF EXISTS `backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chemin` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup`
--

LOCK TABLES `backup` WRITE;
/*!40000 ALTER TABLE `backup` DISABLE KEYS */;
INSERT INTO `backup` VALUES
(1,'D:\\');
/*!40000 ALTER TABLE `backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar`
--

DROP TABLE IF EXISTS `calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT NULL,
  `bgColor` varchar(255) DEFAULT NULL,
  `type` varchar(55) DEFAULT NULL,
  `schedulesChecking` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6EA9A146ED5CA9E6` (`service_id`),
  FOREIGN KEY (`service_id`) REFERENCES`service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar`
--

LOCK TABLES `calendar` WRITE;
/*!40000 ALTER TABLE `calendar` DISABLE KEYS */;
INSERT INTO `calendar` VALUES
(1,1,'#D9534F','Personal',0),
(2,2,'#5BC0DE','Personal',0),
(3,3,'#E15055','Personal',1),
(4,4,'#E15055','Global',0),
(7,6,'#E15055','Personal',0),
(8,5,'#E15055','Personal',0),
(28,25,'#E15055','Personal',0),
(29,26,'#E15055','Personal',0),
(30,31,'#E15055','Personal',0);
/*!40000 ALTER TABLE `calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_vitale`
--

DROP TABLE IF EXISTS `capture_vitale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_vitale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) NOT NULL,
  `height` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `heartBeats` int(11) DEFAULT NULL,
  `pressure` double DEFAULT NULL,
  `bloodPressure` double DEFAULT NULL,
  `cvTime` datetime DEFAULT NULL,
  `waistCircumference` double DEFAULT NULL,
  `hipCircumference` double DEFAULT NULL,
  `cranialPerimeter` double DEFAULT NULL,
  `saturation` double DEFAULT NULL,
  `glucose` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BF13E2562FF6CDF` (`consultation_id`),
  FOREIGN KEY (`consultation_id`) REFERENCES`consultation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_vitale`
--

LOCK TABLES `capture_vitale` WRITE;
/*!40000 ALTER TABLE `capture_vitale` DISABLE KEYS */;
/*!40000 ALTER TABLE `capture_vitale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cardiology_consultation`
--

DROP TABLE IF EXISTS `cardiology_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cardiology_consultation` (
  `id` int(11) NOT NULL,
  `dyslipidemia` longtext DEFAULT NULL,
  `obesity` longtext DEFAULT NULL,
  `coronalHeredity` longtext DEFAULT NULL,
  `hyperuricemia` longtext DEFAULT NULL,
  `earlyMenopause` longtext DEFAULT NULL,
  `diabetes` longtext DEFAULT NULL,
  `smooking` longtext DEFAULT NULL,
  `hta` longtext DEFAULT NULL,
  `ecvSg` longtext DEFAULT NULL,
  `ecvSf` longtext DEFAULT NULL,
  `ecvPag` longtext DEFAULT NULL,
  `ecvPad` longtext DEFAULT NULL,
  `ecvRythme` longtext DEFAULT NULL,
  `ecvVascularBreath` longtext DEFAULT NULL,
  `ecvHeartBreath` longtext DEFAULT NULL,
  `ecvPulse` longtext DEFAULT NULL,
  `ecvSounds` longtext DEFAULT NULL,
  `ecvVenousBed` longtext DEFAULT NULL,
  `ecvEpp` longtext DEFAULT NULL,
  `ecgPr` longtext DEFAULT NULL,
  `coronalHeredityCheck` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `hyperuricemiaCheck` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `earlyMenopauseCheck` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `diabetesCheck` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `smookingCheck` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `htaCheck` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cardiology_consultation`
--

LOCK TABLES `cardiology_consultation` WRITE;
/*!40000 ALTER TABLE `cardiology_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `cardiology_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES
(0,'Tous',NULL);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkup`
--

DROP TABLE IF EXISTS `checkup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) NOT NULL,
  `checkup_1` varchar(255) DEFAULT NULL,
  `checkup_2` varchar(255) DEFAULT NULL,
  `checkup_3` varchar(255) DEFAULT NULL,
  `checkup_4` varchar(255) DEFAULT NULL,
  `checkup_5` varchar(255) DEFAULT NULL,
  `checkup_6` varchar(255) DEFAULT NULL,
  `checkup_7` varchar(255) DEFAULT NULL,
  `checkup_8` varchar(255) DEFAULT NULL,
  `checkup_9` varchar(255) DEFAULT NULL,
  `checkup_10` varchar(255) DEFAULT NULL,
  `checkupName_1` varchar(255) DEFAULT NULL,
  `checkupName_2` varchar(255) DEFAULT NULL,
  `checkupName_3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FD1B7CAF62FF6CDF` (`consultation_id`),
  FOREIGN KEY (`consultation_id`) REFERENCES`consultation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkup`
--

LOCK TABLES `checkup` WRITE;
/*!40000 ALTER TABLE `checkup` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultation`
--

DROP TABLE IF EXISTS `consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultation` (
  `id` int(11) NOT NULL,
  `motive` longtext DEFAULT NULL,
  `diagnostic` longtext DEFAULT NULL,
  `notifiableDiseases` longtext DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `user_list_id` int(11) NOT NULL,
  `behavior` longtext DEFAULT NULL,
  `todayTest` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_964685A665A30881` (`user_list_id`),
  FOREIGN KEY (`user_list_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultation`
--

LOCK TABLES `consultation` WRITE;
/*!40000 ALTER TABLE `consultation` DISABLE KEYS */;
INSERT INTO `consultation` VALUES
(2,NULL,NULL,NULL,NULL,24,NULL,NULL),
(3,NULL,NULL,NULL,NULL,24,NULL,NULL),
(4,NULL,NULL,NULL,NULL,24,NULL,NULL),
(5,NULL,NULL,NULL,NULL,24,NULL,NULL),
(6,NULL,NULL,NULL,NULL,24,NULL,NULL),
(7,NULL,NULL,NULL,NULL,24,NULL,NULL),
(8,'douleurs irradiante au niveau de la 48',NULL,NULL,NULL,27,NULL,NULL),
(9,NULL,NULL,NULL,NULL,27,NULL,NULL),
(10,NULL,NULL,NULL,NULL,25,NULL,NULL),
(11,NULL,NULL,NULL,NULL,28,NULL,NULL),
(292,NULL,NULL,NULL,NULL,33,NULL,NULL),
(293,NULL,NULL,NULL,NULL,33,NULL,NULL),
(294,'neceste exo',NULL,NULL,NULL,33,NULL,NULL),
(295,NULL,NULL,NULL,NULL,33,NULL,NULL),
(296,NULL,NULL,NULL,NULL,33,NULL,NULL),
(297,NULL,NULL,NULL,NULL,33,NULL,NULL),
(298,NULL,NULL,NULL,NULL,28,NULL,NULL),
(299,'douleurs au niveau de la 27',NULL,NULL,NULL,27,NULL,NULL),
(32719,NULL,NULL,NULL,NULL,32,NULL,NULL),
(32720,NULL,NULL,NULL,NULL,27,NULL,NULL),
(32721,NULL,NULL,NULL,NULL,38,NULL,NULL),
(32722,NULL,NULL,NULL,NULL,38,NULL,NULL),
(32723,NULL,NULL,NULL,NULL,31,NULL,NULL);
/*!40000 ALTER TABLE `consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `convention`
--

DROP TABLE IF EXISTS `convention`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `convention` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `percentage` double DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(55) DEFAULT NULL,
  `fax` varchar(55) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `trade_register` varchar(255) DEFAULT NULL,
  `tax_registration` varchar(55) DEFAULT NULL,
  `article_taxation` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `convention`
--

LOCK TABLES `convention` WRITE;
/*!40000 ALTER TABLE `convention` DISABLE KEYS */;
/*!40000 ALTER TABLE `convention` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dental_diagram`
--

DROP TABLE IF EXISTS `dental_diagram`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dental_diagram` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `tooth_number` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `tooth_state` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `consultation_id` int(11) DEFAULT NULL,
  `current_acts` longtext DEFAULT NULL,
  `next_acts` longtext DEFAULT NULL,
  `visible` int(11) DEFAULT NULL,
  `reason` varchar(50) DEFAULT NULL,
  `document_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9ACB2E556B899279` (`patient_id`),
  KEY `IDX_9ACB2E5562FF6CDF` (`consultation_id`),
  KEY `IDX_9ACB2E55C33F7837` (`document_id`),
  FOREIGN KEY (`consultation_id`) REFERENCES`consultation` (`id`),
  FOREIGN KEY (`patient_id`) REFERENCES`patient` (`id`),
  FOREIGN KEY (`document_id`) REFERENCES`document` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28883 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dental_diagram`
--

LOCK TABLES `dental_diagram` WRITE;
/*!40000 ALTER TABLE `dental_diagram` DISABLE KEYS */;
INSERT INTO `dental_diagram` VALUES
(4,2,'2023-02-03','s:2:\"36\";','-','1',2,NULL,NULL,1,NULL,NULL),
(22,14,'2023-02-04','s:2:\"35\";','-','1',14,NULL,NULL,1,NULL,NULL),
(24,21,'2023-02-04','s:2:\"44\";','-','1',22,NULL,NULL,1,NULL,NULL),
(25,11,'2023-02-04','s:2:\"35\";','-','1',11,NULL,NULL,1,NULL,NULL),
(26,23,'2023-02-04','s:2:\"46\";','-','1',25,NULL,NULL,1,NULL,NULL),
(27,8,'2023-02-04','s:2:\"48\";','-','3',26,NULL,NULL,1,NULL,NULL),
(29,16,'2023-02-04','s:2:\"15\";','-','1',17,NULL,NULL,1,NULL,NULL),
(30,28,'2023-02-04','s:2:\"38\";','-','1',33,NULL,NULL,1,NULL,NULL),
(31,25,'2023-02-04','s:15:\"toute les dents\";','-','7',29,NULL,NULL,1,NULL,NULL),
(32,24,'2023-02-04','s:8:\"65,74,75\";','-','1',27,NULL,NULL,1,NULL,NULL),
(33,47,'2023-02-04','s:15:\"toute les dents\";','-','6',45,NULL,NULL,1,NULL,NULL),
(28880,11792,'2024-11-05','s:2:\"27\";','-','6',32717,NULL,NULL,1,NULL,NULL),
(28881,11458,'2024-11-05','s:2:\"12\";','-','1',32711,NULL,NULL,1,NULL,NULL),
(28882,11458,'2024-11-05','s:2:\"22\";','-','1',32711,NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `dental_diagram` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dental_diagram_udc`
--

DROP TABLE IF EXISTS `dental_diagram_udc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dental_diagram_udc` (
  `dental_diagram_id` int(11) NOT NULL,
  `udc_id` int(11) NOT NULL,
  PRIMARY KEY (`dental_diagram_id`,`udc_id`),
  KEY `IDX_C3EE14B7B873BE5` (`dental_diagram_id`),
  KEY `IDX_C3EE14B7360CA893` (`udc_id`),
  FOREIGN KEY (`udc_id`) REFERENCES`udc` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`dental_diagram_id`) REFERENCES`dental_diagram` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dental_diagram_udc`
--

LOCK TABLES `dental_diagram_udc` WRITE;
/*!40000 ALTER TABLE `dental_diagram_udc` DISABLE KEYS */;
INSERT INTO `dental_diagram_udc` VALUES
(4,1079),
(5,482),
(6,1079),
(7,481),
(8,1079),
(9,1079),
(10,477),
(12,1129),
(14,482),
(15,1129),
(16,485),
(18,485),
(19,489),
(20,489),
(21,489),
(28877,159),
(28878,1079),
(28879,481),
(28880,489),
(28881,483),
(28882,483);
/*!40000 ALTER TABLE `dental_diagram_udc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `title` varchar(95) DEFAULT NULL,
  `company` varchar(195) DEFAULT NULL,
  `personOpeningAccount` varchar(195) NOT NULL,
  `dateOpened` date NOT NULL,
  `taxRateArea` varchar(255) DEFAULT NULL,
  `licenceNumber` varchar(255) DEFAULT NULL,
  `numProf` int(11) DEFAULT NULL,
  `bgColor` varchar(255) DEFAULT NULL,
  `consult_percent` double DEFAULT NULL,
  `care_percent` double DEFAULT NULL,
  `prosthesis_percent` double DEFAULT NULL,
  `surgery_percent` double DEFAULT NULL,
  `periodontics_percent` double DEFAULT NULL,
  `implant_percent` double DEFAULT NULL,
  `orthodontics_percent` double DEFAULT NULL,
  `expendable_percent` double DEFAULT NULL,
  `implant_exp_percent` double DEFAULT NULL,
  `orthodontics_exp_percent` double DEFAULT NULL,
  `prosthesis_exp_percent` double DEFAULT NULL,
  `invisalign_exp_percent` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES
(21,'Omnipraticien',NULL,'kbmadmin','2021-02-24',NULL,NULL,NULL,'45F84A',0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL),
(22,'Docteur',NULL,'kbmadmin','2018-10-03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(23,'Omnipraticien',NULL,'kbmadmin','2022-02-16',NULL,NULL,NULL,'#FFFFFF',0,0,0,0,0,0,0,0,0,0,0,0),
(24,'Omnipraticien',NULL,'admin','2023-02-03',NULL,NULL,NULL,'AC6B4B',0,0,0,0,0,0,0,0,0,0,0,0),
(25,'Omnipraticien',NULL,'admin','2023-02-04',NULL,NULL,NULL,'3823FF',0,0,0,0,0,0,0,0,0,0,0,0),
(41,'Omnipraticien',NULL,'admin','2024-01-30',NULL,NULL,NULL,'FFFFFF',0,0,0,0,0,0,0,0,0,0,0,0),
(42,'Omnipraticien',NULL,'admin','2024-04-17',NULL,NULL,NULL,'FFD1F9',0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `persist` varchar(255) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `convention_id` int(11) DEFAULT NULL,
  `duration` date DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D8698A7662FF6CDF` (`consultation_id`),
  KEY `IDX_D8698A76A2ACEBCC` (`convention_id`),
  FOREIGN KEY (`consultation_id`) REFERENCES`consultation` (`id`),
  FOREIGN KEY (`convention_id`) REFERENCES`convention` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27669 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` VALUES
(2,2,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br />\r\n						Adresse<br />\r\n						<span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br />\r\n						T&eacute;l:&nbsp;</span></span></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 03/02/2023&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 2<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - MARTIN ERWAN<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 123 an(s)&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2023-02-03','Invoice',NULL,NULL,NULL,NULL,NULL),
(3,3,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br />\r\n						Adresse<br />\r\n						<span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br />\r\n						T&eacute;l:&nbsp;</span></span></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 03/02/2023&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 3<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - BERNARD STECY<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 123 an(s)&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2023-02-03','Invoice',NULL,NULL,NULL,NULL,NULL),
(4,4,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br />\r\n						Adresse<br />\r\n						<span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br />\r\n						T&eacute;l:&nbsp;</span></span></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 03/02/2023&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 4<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - THOMAS LUDOVIC<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 123 an(s)&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2023-02-03','Invoice',NULL,NULL,NULL,NULL,NULL),
(5,5,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br />\r\n						Adresse<br />\r\n						<span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br />\r\n						T&eacute;l:&nbsp;</span></span></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 03/02/2023&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 5<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - PETIT MARLON<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 123 an(s)&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2023-02-03','Invoice',NULL,NULL,NULL,NULL,NULL),
(6,6,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br />\r\n						Adresse<br />\r\n						<span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br />\r\n						T&eacute;l:&nbsp;</span></span></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 03/02/2023&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 6<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - AKSEL MONIQUE<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 123 an(s)&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2023-02-03','Invoice',NULL,NULL,NULL,NULL,NULL),
(27627,32666,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n							<tbody>\r\n								<tr>\r\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\r\n								</tr>\r\n								<tr>\r\n									<td>\r\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\r\n\r\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 04/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 11474<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - MOLINARI THOMAS<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 18 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-04','Invoice',NULL,NULL,NULL,NULL,NULL),
(27628,32664,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\n	<tbody>\n		<tr>\n			<td style=\"width:350px\">\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\n				<tbody>\n					<tr>\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\n					</tr>\n					<tr>\n						<td style=\"text-align:center\">\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n							<tbody>\n								<tr>\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\n								</tr>\n								<tr>\n									<td>\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\n\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\n									</td>\n								</tr>\n							</tbody>\n						</table>\n						</td>\n					</tr>\n				</tbody>\n			</table>\n			</td>\n			<td>\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\n				<tbody>\n					<tr>\n						<td>&nbsp;</td>\n					</tr>\n				</tbody>\n			</table>\n			</td>\n			<td>\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\n				<tbody>\n					<tr>\n						<td>\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _11777</span></span></strong></p>\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 04/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 11777<br />\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - MOUNIER ANDREA<br />\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 35 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\n					</tr>\n					<tr>\n						<td>&nbsp;</td>\n					</tr>\n				</tbody>\n			</table>\n			</td>\n		</tr>\n	</tbody>\n</table>\n&nbsp;<br />\n<br />\n&nbsp;\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\n	<tbody>\n		<tr>\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\n		</tr>\n	</tbody>\n</table>\n&nbsp;\n\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"min-width:800px; width:100%\">\n	<tbody>\n		<tr>\n			<td style=\"width:38%\">Dent 46 : Obturation au composite</td>\n			<td style=\"text-align:center; width:16%\">6000.00DA</td>\n			<td style=\"text-align:center; width:16%\">0.00DA</td>\n			<td style=\"text-align:center; width:10%\">1</td>\n			<td style=\"text-align:center; width:20%\">6000.00DA</td>\n		</tr>\n	</tbody>\n</table>\n\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"min-width:800px; width:100%\">\n	<tbody>\n		<tr>\n			<td style=\"width:38%\">Dent 48 : Obturation au composite</td>\n			<td style=\"text-align:center; width:16%\">6000.00DA</td>\n			<td style=\"text-align:center; width:16%\">0.00DA</td>\n			<td style=\"text-align:center; width:10%\">1</td>\n			<td style=\"text-align:center; width:20%\">6000.00DA</td>\n		</tr>\n	</tbody>\n</table>\n\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"min-width:800px; width:100%\">\n	<tbody>\n		<tr>\n			<td style=\"width:38%\">&nbsp;Detartrage</td>\n			<td style=\"text-align:center; width:16%\">3000.00DA</td>\n			<td style=\"text-align:center; width:16%\">0.00DA</td>\n			<td style=\"text-align:center; width:10%\">1</td>\n			<td style=\"text-align:center; width:20%\">3000.00DA</td>\n		</tr>\n	</tbody>\n</table>\n\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"min-width:800px; width:100%\">\n	<tbody>\n		<tr>\n			<td style=\"width:38%\">&nbsp;consultation 1</td>\n			<td style=\"text-align:center; width:16%\">1000.00DA</td>\n			<td style=\"text-align:center; width:16%\">0.00DA</td>\n			<td style=\"text-align:center; width:10%\">1</td>\n			<td style=\"text-align:center; width:20%\">1000.00DA</td>\n		</tr>\n	</tbody>\n</table>\n\n<ul>\n</ul>\n\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\n	<tbody>\n		<tr>\n			<td style=\"width:550px\">&nbsp;</td>\n			<td>\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:250px\">\n				<tbody>\n					<tr>\n						<td>\n						<table cellpadding=\"0\" cellspacing=\"0\">\n							<tbody>\n								<tr>\n									<td><strong>&nbsp; &nbsp; &nbsp;Total remise :</strong></td>\n									<td><strong>0.00DA</strong></td>\n								</tr>\n								<tr>\n									<td><strong>&nbsp; &nbsp;&nbsp; THT :</strong></td>\n									<td><strong>16000.00DA</strong></td>\n								</tr>\n								<tr>\n									<td><strong>&nbsp; &nbsp;&nbsp; TVA (0%) :</strong></td>\n									<td><strong>0.00DA</strong></td>\n								</tr>\n								<tr>\n									<td><strong>&nbsp; &nbsp;&nbsp; TTC :</strong></td>\n									<td><strong>16000.00DA</strong></td>\n								</tr>\n							</tbody>\n						</table>\n						</td>\n					</tr>\n				</tbody>\n			</table>\n			</td>\n		</tr>\n	</tbody>\n</table>\n','2024-11-04','Invoice',NULL,'',NULL,NULL,NULL),
(27654,32699,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n							<tbody>\r\n								<tr>\r\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\r\n								</tr>\r\n								<tr>\r\n									<td>\r\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\r\n\r\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 11787<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - BENFRANCE YASMDIANA<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 27 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL),
(27655,32700,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n							<tbody>\r\n								<tr>\r\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\r\n								</tr>\r\n								<tr>\r\n									<td>\r\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\r\n\r\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 11788<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - MAZURE CLÉMENT<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 30 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL),
(27656,32702,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n							<tbody>\r\n								<tr>\r\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\r\n								</tr>\r\n								<tr>\r\n									<td>\r\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\r\n\r\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 8259<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - MATISSEI LUCIE<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 23 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL),
(27657,32705,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n							<tbody>\r\n								<tr>\r\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\r\n								</tr>\r\n								<tr>\r\n									<td>\r\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\r\n\r\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 10486<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - BROSSARD TONY<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 51 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL),
(27658,32707,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n							<tbody>\r\n								<tr>\r\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\r\n								</tr>\r\n								<tr>\r\n									<td>\r\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\r\n\r\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 1224<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - MAGNIN ROBERT<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 20 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL),
(27659,32710,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br />\r\n						Adresse<br />\r\n						<span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br />\r\n						T&eacute;l:&nbsp;</span></span></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 11789<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - L HOSTIS LAURENT<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 40 an(s)&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL),
(27667,32717,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br />\r\n						Adresse<br />\r\n						<span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br />\r\n						T&eacute;l:&nbsp;</span></span></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 11792<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - BENTROUVE ELODIE<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 53 an(s)&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL),
(27668,32711,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n							<tbody>\r\n								<tr>\r\n									<td><span style=\"font-size:24px\">&nbsp; &nbsp; &nbsp; &nbsp;</span></td>\r\n								</tr>\r\n								<tr>\r\n									<td>\r\n									<div style=\"text-align:right\"><span style=\"font-size:24px\"><em><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></em></span></div>\r\n\r\n									<div><span style=\"font-size:24px\"><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7 J</strong></em></span></div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p>\r\n						<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Poitiers<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le 05/11/2024&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - 11458<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - BOURENATO CHLOÉ<br />\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - 48 an(s)&nbsp;<strong>&nbsp;&nbsp;</strong></span></span><strong>&nbsp;</strong></td>\r\n					</tr>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;<br />\r\n<br />\r\n&nbsp;\r\n<table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td>\r\n			<td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td>\r\n			<td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td>\r\n			<td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;\r\n\r\n<ul>\r\n</ul>','2024-11-05','Invoice',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_scan`
--

DROP TABLE IF EXISTS `document_scan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_scan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_63073F3D75FA0FF2` (`visit_id`),
  FOREIGN KEY (`visit_id`) REFERENCES`visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26743 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_scan`
--

LOCK TABLES `document_scan` WRITE;
/*!40000 ALTER TABLE `document_scan` DISABLE KEYS */;
INSERT INTO `document_scan` VALUES
(237,2,NULL),
(238,3,NULL),
(239,4,NULL),
(240,5,NULL),
(241,6,NULL),
(242,7,NULL),
(243,13,NULL),
(244,18,NULL),
(245,19,NULL),
(246,15,NULL),
(247,16,NULL),
(249,10,NULL),
(26729,32699,NULL),
(26730,32700,NULL),
(26731,32702,NULL),
(26732,32705,NULL),
(26733,32707,NULL),
(26734,32710,NULL),
(26735,32706,NULL),
(26736,32701,NULL),
(26737,32712,NULL),
(26738,32715,NULL),
(26739,32703,NULL),
(26740,32709,NULL),
(26741,32717,NULL),
(26742,32711,NULL);
/*!40000 ALTER TABLE `document_scan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_sent`
--

DROP TABLE IF EXISTS `document_sent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_sent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `documentType` varchar(255) DEFAULT NULL,
  `idDocument` varchar(255) DEFAULT NULL,
  `mailRecipient` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_sent`
--

LOCK TABLES `document_sent` WRITE;
/*!40000 ALTER TABLE `document_sent` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_sent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_type`
--

DROP TABLE IF EXISTS `document_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `user_created_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2B6ADBBAED5CA9E6` (`service_id`),
  KEY `IDX_2B6ADBBAF987D8A8` (`user_created_id`),
  FOREIGN KEY (`service_id`) REFERENCES`service` (`id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_type`
--

LOCK TABLES `document_type` WRITE;
/*!40000 ALTER TABLE `document_type` DISABLE KEYS */;
INSERT INTO `document_type` VALUES
(1,12,24,'test','iuiuyik;ufuot;:gfu;ro<br />\r\n&nbsp;','2023-02-06','Certificate'),
(2,12,26,'certificat absence','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:320px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:320px\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<div style=\"text-align:left\"><br />\r\n						<em><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:20px\"><strong>&nbsp; &nbsp; </strong></span><span style=\"font-size:26px\"><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></span></span></em></div>\r\n\r\n						<div style=\"text-align:left\"><em><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:26px\"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7J</strong></span><span style=\"font-size:20px\"><strong>&nbsp; &nbsp;&nbsp;</strong></span></span></em></div>\r\n\r\n						<div style=\"text-align:right\"><span style=\"font-family:Arial,Helvetica,sans-serif\"><em><span style=\"font-size:18px\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></em></span></div>\r\n\r\n						<div style=\"text-align:left\">&nbsp;</div>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"padding:2px; width:250px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:18px\">Poitiers, le : 22/09/2023<br />\r\n						Nom : BENDUCROCQA<br />\r\n						Pr&eacute;noms : ROGER<br />\r\n						Age :&nbsp; 26 an(s)&nbsp;</span></span></p>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\"><span style=\"font-size:24px\"><strong><u>CERTIFICAT M&Eacute;DICAL&nbsp;</u></strong></span></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n<span style=\"color:#ffffff\">Je&nbsp; &nbsp;<span style=\"font-size:22px\">&nbsp; &nbsp;&nbsp;</span></span><span style=\"font-size:22px\">Je sous-sign&eacute;, certifie avoir re&ccedil;u le patient sus-nomm&eacute; qui s&#39;est pr&eacute;sent&eacute; pour l&#39;extraction de sa dent de sagesse inf&eacute;rieure droite, cari&eacute;e.&nbsp;<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; Le patient a b&eacute;n&eacute;fici&eacute; d&#39;une extraction chirurgicale de sa dent de sagesse aujourd&#39;hui le 22.09.2023 et n&eacute;cessite un repos de trois (03) jours, sauf complications.&nbsp;</span>','2023-09-22','Certificate'),
(3,12,26,'certificat 2','<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"width:320px\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:320px\">\r\n							<tbody>\r\n								<tr>\r\n									<td style=\"text-align:center\">\r\n									<div style=\"text-align:left\"><br />\r\n									<em><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:20px\"><strong>&nbsp; &nbsp; </strong></span><span style=\"font-size:26px\"><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></span></span></em></div>\r\n\r\n									<div style=\"text-align:left\"><em><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:26px\"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7J</strong></span><span style=\"font-size:20px\"><strong>&nbsp; &nbsp;&nbsp;</strong></span></span></em></div>\r\n\r\n									<div style=\"text-align:right\"><span style=\"font-family:Arial,Helvetica,sans-serif\"><em><span style=\"font-size:18px\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></em></span></div>\r\n\r\n									<div style=\"text-align:left\">&nbsp;</div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n						<td>\r\n						<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\">\r\n							<tbody>\r\n								<tr>\r\n									<td>&nbsp;</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n						<td>\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"padding:2px; width:250px\">\r\n							<tbody>\r\n								<tr>\r\n									<td>\r\n									<p><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:18px\">Poitiers, le : 30/09/2023<br />\r\n									Nom : CHMAHERE<br />\r\n									Pr&eacute;noms : Lakhder<br />\r\n									Age :&nbsp; 39&nbsp;an(s)&nbsp;</span></span></p>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"text-align:center\">&nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-size:24px\"><strong><u>CERTIFICAT M&Eacute;DICAL&nbsp;</u></strong></span></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			<br />\r\n			<br />\r\n			<br />\r\n			<span style=\"color:#ffffff\">Je&nbsp; &nbsp;<span style=\"font-size:22px\">&nbsp; &nbsp;&nbsp;</span></span><span style=\"font-size:22px\">Je sous-sign&eacute;, certifie avoir re&ccedil;u le patient sus-nomm&eacute; qui s&#39;est pr&eacute;sent&eacute; pour l&#39;extraction chirurgicale de sa dent de sagesse inf&eacute;rieure gauche.&nbsp;<br />\r\n			&nbsp; &nbsp; &nbsp; &nbsp; Le patient a b&eacute;n&eacute;fici&eacute; d&#39;une extraction chirurgicale de sa dent de sagesse aujourd&#39;hui le 30.09.2023 et n&eacute;cessite un repos de quatre (04) jours, sauf complications.&nbsp;</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n<span style=\"color:#ffffff\">&nbsp;</span>','2023-09-30','Certificate'),
(4,12,26,'1lettre d\'orientation','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:350px\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"text-align:center\">\r\n						<div style=\"text-align:right\"><em><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:20px\"><strong>&nbsp;Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;<br />\r\n						7/7J&nbsp;&nbsp;&nbsp;</strong></span></span></em></div>\r\n\r\n						<div style=\"text-align:right\"><span style=\"font-family:Arial,Helvetica,sans-serif\"><em><span style=\"font-size:18px\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></em></span></div>\r\n\r\n						<div style=\"text-align:left\">&nbsp;</div>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"padding:2px; width:200px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>\r\n						<p><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:18px\">Poitiers, le 07/10/2023<br />\r\n						&nbsp; &nbsp;Nom : ARTHURI<br />\r\n						&nbsp; &nbsp;Pr&eacute;noms : HUGUETTE<br />\r\n						&nbsp; &nbsp;Age :&nbsp; 28 an(s)&nbsp;</span></span></p>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\"><u><span style=\"font-size:24px\"><span style=\"font-family:Arial,Helvetica,sans-serif\"><strong>LETTRE D&#39;ORIENTATION</strong></span></span></u></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n&nbsp;&nbsp;<br />\r\n<br />\r\n<br />\r\n<br />\r\nCher confr&egrave;re,&nbsp;<br />\r\n<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Permettez moi de vous adresser la patiente sus-nomm&eacute;e, qui s&#39;est pr&eacute;sent&eacute; pour une extraction de sa dent de sagesse inf&eacute;rieure.&nbsp;<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;La patiente est actuellement sous anti agr&eacute;gants plaquettaires pour une thrombose veineuse.&nbsp;<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Veuillez SVP pr&eacute;ciser la possibilit&eacute; d&#39;une extraction chirurgicale de la dent de sagesse.&nbsp;<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;Cordialement.&nbsp;','2023-10-07','OrientationRequest'),
(5,12,39,'certaficat','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"width:350px\">\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:300px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"width:320px\">\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:320px\">\r\n							<tbody>\r\n								<tr>\r\n									<td style=\"text-align:center\">\r\n									<div style=\"text-align:left\"><br />\r\n									<em><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:20px\"><strong>&nbsp; &nbsp; </strong></span><span style=\"font-size:26px\"><strong>Dental Clinic&nbsp;24/24 H&nbsp; &nbsp;</strong></span></span></em></div>\r\n\r\n									<div style=\"text-align:left\"><em><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:26px\"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7/7J</strong></span><span style=\"font-size:20px\"><strong>&nbsp; &nbsp;&nbsp;</strong></span></span></em></div>\r\n\r\n									<div style=\"text-align:right\"><span style=\"font-family:Arial,Helvetica,sans-serif\"><em><span style=\"font-size:18px\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></em></span></div>\r\n\r\n									<div style=\"text-align:left\">&nbsp;</div>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n						<td>\r\n						<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\">\r\n							<tbody>\r\n								<tr>\r\n									<td>&nbsp;</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n						<td>\r\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"padding:2px; width:250px\">\r\n							<tbody>\r\n								<tr>\r\n									<td>\r\n									<p><span style=\"font-family:Arial,Helvetica,sans-serif\"><span style=\"font-size:18px\">Poitiers, le : 23/02/2024<br />\r\n									Nom : Mahammed Otsmane<br />\r\n									Pr&eacute;noms : Achref<br />\r\n									Age :&nbsp; 23&nbsp;an(s)&nbsp;</span></span></p>\r\n									</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"text-align:center\">&nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\"><span style=\"font-size:24px\"><strong><u>CERTIFICAT M&Eacute;DICAL&nbsp;</u></strong></span></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"text-align:center\">&nbsp;</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			<br />\r\n			<span style=\"color:#ffffff\">Je&nbsp; &nbsp;<span style=\"font-size:22px\">&nbsp; &nbsp;&nbsp;</span></span><span style=\"font-size:22px\">Je sous-sign&eacute;, certifie avoir re&ccedil;u le patient sus-nomm&eacute; qui s&#39;est pr&eacute;sent&eacute; pour l&#39;extraction de sa dent de sagesse, cari&eacute;e.&nbsp;<br />\r\n			&nbsp; &nbsp; &nbsp; &nbsp; Le patient a b&eacute;n&eacute;fici&eacute; d&#39;une extraction de sa dent de sagesse aujourd&#39;hui le 23.02.2024 et n&eacute;cessite un repos d&#39;un seul jour (01) jour, sauf complications.&nbsp;</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n<span style=\"color:#ffffff\">&nbsp;</span>','2024-02-23','Certificate');
/*!40000 ALTER TABLE `document_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drug`
--

DROP TABLE IF EXISTS `drug`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drug` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `denomination` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `form` varchar(255) DEFAULT NULL,
  `Type` varchar(255) DEFAULT NULL,
  `dosage` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `posology` longtext DEFAULT NULL,
  `quantity` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_43EB7A3E12469DE2` (`category_id`),
  KEY `brand_idx` (`brand`),
  FOREIGN KEY (`category_id`) REFERENCES`category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4591 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drug`
--

LOCK TABLES `drug` WRITE;
/*!40000 ALTER TABLE `drug` DISABLE KEYS */;
INSERT INTO `drug` VALUES
(1,'CETICHATENETARLIE VILAINLORHYDRATE','ALBUISINE','Comprimé(s)','Boite(s)','10MG',NULL,NULL,NULL),
(2,'CETICHATENETARLIE VILAINLORHYDRATE','ARTIZ','Comprimé(s)','Boite(s)','10MG',NULL,NULL,NULL),
(3,'CETICHATENETARLIE VILAINLORHYDRATE','CERIN','Comprimé(s)','Boite(s)','10MG',NULL,NULL,NULL),
(4,'CETICHATENETARLIE VILAINLORHYDRATE','CETICHATENETARLIE MYLAN','Comprimé(s)','Boite(s)','10MG',NULL,NULL,NULL),
(5,'CETICHATENETARLIE VILAINLORHYDRATE','CETICHATENETARLIE PHYSIOPHARM','Comprimé(s)','Boite(s)','10MG',NULL,NULL,NULL),
(6,'CETICHATENETARLIE VILAINLORHYDRATE','CETRYN','Comprimé(s)','Boite(s)','10MG',NULL,NULL,NULL),
(4576,NULL,'ACLASTA 100ML',NULL,NULL,NULL,NULL,'1 dose 2 fois / 2 jrs  le soir ','pendant 2 jour(s) '),
(4577,NULL,'PARACETAMOL BIOCARE 300MG',NULL,NULL,NULL,NULL,'1 Comprimé 1 fois / jr le matin ','pendant 1 jour(s) '),
(4578,NULL,'qwerty',NULL,NULL,NULL,NULL,'5 sachet  ',''),
(4579,NULL,'Viberzi',NULL,NULL,NULL,NULL,'1 Comprimé 1 fois / jr le matin ','pendant 1 jour(s) '),
(4580,NULL,'PARACETAL 500MG',NULL,NULL,NULL,NULL,'1 Comprimé 1 fois / jr le matin ','pendant 1 semaine(s) '),
(4581,NULL,'Tamidexine',NULL,NULL,NULL,NULL,'1 Comprimé 1 fois / jr le matin ','pendant 1 semaine(s) '),
(4582,NULL,'Merivol N° 05',NULL,NULL,NULL,NULL,'1 Comprimé 1 fois / jr  ',''),
(4583,NULL,'ACIDE ZOLEDRONIQUE HIKMA 4MG',NULL,NULL,NULL,NULL,'1 comprimé 1 fois / jr  ','QSP 1 semaine(s) '),
(4584,NULL,'AMOXICILLDIANA EG 500MG/5ML**',NULL,NULL,NULL,NULL,'  01 cp 03/jrs',' qsp 08jrs'),
(4585,NULL,'AUGMENTIMEX ADULTES 500MG/62,5MG',NULL,NULL,NULL,NULL,'  1 cp ',' '),
(4586,NULL,'AMOCLAN BID 875MG/125MG',NULL,NULL,NULL,NULL,'  1g',' 2 btes'),
(4587,NULL,'AMOXICILLDIANA EG 1G',NULL,NULL,NULL,NULL,'  01 cp 03/jrs',' QSP 08 jrs'),
(4588,NULL,'CLAMOXYL 1G',NULL,NULL,NULL,NULL,'  ',' 7'),
(4589,NULL,'CLAMOXYL 1G',NULL,NULL,NULL,NULL,'3',' 7'),
(4590,NULL,'AUGMENTIN 1G/200MG',NULL,NULL,NULL,NULL,'  ',' ');
/*!40000 ALTER TABLE `drug` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `endocrinology_consultation`
--

DROP TABLE IF EXISTS `endocrinology_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `endocrinology_consultation` (
  `id` int(11) NOT NULL,
  `last_menstruation` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endocrinology_consultation`
--

LOCK TABLES `endocrinology_consultation` WRITE;
/*!40000 ALTER TABLE `endocrinology_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `endocrinology_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evenement`
--

DROP TABLE IF EXISTS `evenement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evenement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `startDatetime` datetime NOT NULL,
  `endDatetime` datetime DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `allDay` varchar(255) DEFAULT NULL,
  `bgColor` varchar(255) DEFAULT NULL,
  `fgColor` varchar(255) DEFAULT NULL,
  `cssClass` varchar(255) DEFAULT NULL,
  `calendar_id` int(11) NOT NULL,
  `discr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B26681EA40A2C8` (`calendar_id`),
  FOREIGN KEY (`calendar_id`) REFERENCES`calendar` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17549 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evenement`
--

LOCK TABLES `evenement` WRITE;
/*!40000 ALTER TABLE `evenement` DISABLE KEYS */;
INSERT INTO `evenement` VALUES
(1,'10 - DURAND JACQUELDIANA - 0660395947. consultation','2023-02-04 10:00:00','2023-02-04 10:15:00','/web/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(3,'13 - BERREGAD BARRAULT FABRICE - 0663927532. controle','2023-02-04 10:30:00','2023-02-04 10:45:00','/web/fullcalendar/fc-add-events',NULL,'#5DE189','#FFFFFF',NULL,20,'PatientUserEvent'),
(4,'14 - MICHEL MARTDIANA - 0551923301. consultation','2023-02-04 10:00:00','2023-02-04 10:15:00','/web/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(5,'15 - LEFEBVRE ROBERT DIAA EDDDIANA - 0661569255. consultation','2023-02-04 10:30:00','2023-02-04 10:45:00','/web/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(6,'13 - BERREGAD BARRAULT FABRICE - 0663927532. Exo DDS','2023-02-11 09:00:00','2023-02-11 09:45:00','/web/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(7,'16 - PFISTEROUGUILLEMETTES MICHEL - 0777936789. consultation','2023-02-04 11:00:00','2023-02-04 11:15:00','/web/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17535,'10486 - BROSSARD TONY - 0553733803.   => Confirmé','2024-11-05 11:00:00','2024-11-05 11:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#3aff80',NULL,20,'PatientUserEvent'),
(17536,'11743 - MOLARD MOJEANDIANA - 0661432724.   => Confirmé','2024-11-05 17:00:00','2024-11-05 17:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#3aff80',NULL,20,'PatientUserEvent'),
(17537,'11329 - PROST ADEM - 0659706226.  ','2024-11-11 14:00:00','2024-11-11 14:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17538,'10663 - AYLANE TONY GONTRAN - 0559822892.  ','2024-11-09 15:30:00','2024-11-09 15:45:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17539,'11560 - BOSSE NICOLLEDDDIANA - 0554154567.  ','2024-11-09 13:30:00','2024-11-09 13:45:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17540,'11784 - MAXIMEI ROBERT - 0553598574.  ','2024-11-05 20:00:00','2024-11-05 20:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17541,'11748 - JOUETAEZ TITOUAN - 0770362892.   => Confirmé','2024-11-05 12:00:00','2024-11-05 12:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#3aff80',NULL,20,'PatientUserEvent'),
(17542,'8259 - MATISSEI LUCIE - 0783164373.  ','2024-11-10 09:00:00','2024-11-10 09:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17543,'10486 - BROSSARD TONY - 0553733803.  ','2024-11-13 10:00:00','2024-11-13 10:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17544,'11257 - BENGEOFFREY TONY - 0657811993.  ','2024-11-10 09:30:00','2024-11-10 09:45:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17545,'11791 - GILBERTJI SERGINE - 0796616839.  ','2024-11-07 14:30:00','2024-11-07 14:45:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17546,'1224 - MAGNIN ROBERT - 0667038857.  ','2024-11-07 12:30:00','2024-11-07 12:45:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17547,'6851 - PFISTER MARIE-JOSÉ JEANNOT - 0772357425.  ','2024-11-07 17:00:00','2024-11-07 17:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent'),
(17548,'11458 - BOURENATO CHLOÉ - 0675190349.  ','2024-11-12 10:00:00','2024-11-12 10:15:00','/mydental/web/app.php/fullcalendar/fc-add-events',NULL,'#E15055','#FFFFFF',NULL,20,'PatientUserEvent');
/*!40000 ALTER TABLE `evenement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `cost` double DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateEntry` date DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `date_expiration` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `entered_by_id` int(11) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `remaining_amount` double DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2D3A8DA687F4FB17` (`doctor_id`),
  KEY `IDX_2D3A8DA6C443EDD` (`entered_by_id`),
  KEY `IDX_2D3A8DA6A53A8AA` (`provider_id`),
  FOREIGN KEY (`doctor_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`provider_id`) REFERENCES`supplier` (`id`),
  FOREIGN KEY (`entered_by_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense`
--

LOCK TABLES `expense` WRITE;
/*!40000 ALTER TABLE `expense` DISABLE KEYS */;
INSERT INTO `expense` VALUES
(1,'Compresses',1000,'2023-03-11','2023-03-11',26,NULL,'Materiel',NULL,NULL,NULL,'03',26,1000,0,NULL),
(2,'Sparadrap',5000,'2023-03-11','2023-03-11',26,NULL,'Materiel',NULL,NULL,NULL,'01',26,0,5000,NULL);
/*!40000 ALTER TABLE `expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) DEFAULT NULL,
  `picturePath` varchar(255) DEFAULT NULL,
  `pictureName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8C9F3610C33F7837` (`document_id`),
  FOREIGN KEY (`document_id`) REFERENCES`document_scan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=442 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `general_consultation`
--

DROP TABLE IF EXISTS `general_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_consultation` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_consultation`
--

LOCK TABLES `general_consultation` WRITE;
/*!40000 ALTER TABLE `general_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `general_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graphic_tooth`
--

DROP TABLE IF EXISTS `graphic_tooth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graphic_tooth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picturePath` varchar(255) DEFAULT NULL,
  `pictureName` varchar(255) DEFAULT NULL,
  `acte_liste_udc` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `tooth_number` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1140 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graphic_tooth`
--

LOCK TABLES `graphic_tooth` WRITE;
/*!40000 ALTER TABLE `graphic_tooth` DISABLE KEYS */;
INSERT INTO `graphic_tooth` VALUES
(1,'uploads/Dent','32124d89dcf67786d24d6071b4ee46ed.png','a:1:{i:0;i:218;}','11'),
(2,'uploads/Dent','ef2872d5a9369c3ed8a96606a40a06ae.png','a:1:{i:0;i:218;}','12'),
(3,'uploads/Dent','3c695808e016c98ddfd857b9de2b13c2.png','a:1:{i:0;i:218;}','13'),
(4,'uploads/Dent','df0b0e78e01ebca4e3315680cd3e9afd.png','a:1:{i:0;i:218;}','14'),
(5,'uploads/Dent','37472a7dec0cb4c7e63593d8d905164e.png','a:1:{i:0;i:218;}','15'),
(1137,'uploads/Dent','77960c1576e5ba9aa96258debb29856f.png','a:1:{i:0;i:167;}','45'),
(1138,'uploads/Dent','f58de7fa82cfa4256a95bf7febd5296b.png','a:1:{i:0;i:167;}','46'),
(1139,'uploads/Dent','8d5b9ee6da2bc52aea59db87bc934fc3.png','a:1:{i:0;i:167;}','47');
/*!40000 ALTER TABLE `graphic_tooth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gynecology_consultation`
--

DROP TABLE IF EXISTS `gynecology_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gynecology_consultation` (
  `id` int(11) NOT NULL,
  `last_menstruation` date DEFAULT NULL,
  `obs_t1` longtext DEFAULT NULL,
  `obs_t2` longtext DEFAULT NULL,
  `obs_t3` longtext DEFAULT NULL,
  `husbandObs` longtext DEFAULT NULL,
  `husbandHabit` longtext DEFAULT NULL,
  `husbandMedicalHistory` longtext DEFAULT NULL,
  `attemptFrequency` longtext DEFAULT NULL,
  `attemptDuration` longtext DEFAULT NULL,
  `neck` longtext DEFAULT NULL,
  `breast` longtext DEFAULT NULL,
  `vaginaCollar` longtext DEFAULT NULL,
  `speculum` longtext DEFAULT NULL,
  `femur` longtext DEFAULT NULL,
  `abdominalPerimeter` longtext DEFAULT NULL,
  `biparietalDiameter` longtext DEFAULT NULL,
  `cephalicPerimeter` longtext DEFAULT NULL,
  `husbandOccupation` longtext DEFAULT NULL,
  `fertilityDegree` longtext DEFAULT NULL,
  `pregnancyAttemptNumber` longtext DEFAULT NULL,
  `pregnancyAttemptMethod` longtext DEFAULT NULL,
  `coupleObs` longtext DEFAULT NULL,
  `patientObs` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gynecology_consultation`
--

LOCK TABLES `gynecology_consultation` WRITE;
/*!40000 ALTER TABLE `gynecology_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `gynecology_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historique_test`
--

DROP TABLE IF EXISTS `historique_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historique_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_created_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `code` varchar(55) NOT NULL,
  `price` double DEFAULT NULL,
  `createdDate` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5C2659EEF987D8A8` (`user_created_id`),
  KEY `IDX_5C2659EE1E5D0459` (`test_id`),
  FOREIGN KEY (`test_id`) REFERENCES`test` (`id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historique_test`
--

LOCK TABLES `historique_test` WRITE;
/*!40000 ALTER TABLE `historique_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `historique_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hospital_center`
--

DROP TABLE IF EXISTS `hospital_center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hospital_center` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_created_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `wilaya` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  `updateDate` date DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `webSite` varchar(255) DEFAULT NULL,
  `validation_sms` longtext DEFAULT NULL,
  `cancellation_sms` longtext DEFAULT NULL,
  `update_sms` longtext DEFAULT NULL,
  `reminder_sms` longtext DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  `expirationDate` date DEFAULT NULL,
  `alert_before_expiration` longtext DEFAULT NULL,
  `alert_after_expiration` longtext DEFAULT NULL,
  `delay_before_alert` int(11) DEFAULT NULL,
  `deny_acces` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9F915E77F987D8A8` (`user_created_id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospital_center`
--

LOCK TABLES `hospital_center` WRITE;
/*!40000 ALTER TABLE `hospital_center` DISABLE KEYS */;
INSERT INTO `hospital_center` VALUES
(1,22,'My Dental Clinic','New City','Clinique',NULL,'New City','New City','2016-05-23',NULL,NULL,'Bonjour _prenom _nom ! Votre prochain RDV chez .... est le _date à _heure. Si vous décidez de le reporter, veuillez nous appeler au 0..','Bonjour _prenom _nom ! Votre RDV chez ..... le _date @ _heure est annulé. Veuillez nous rappeler au ... pour prendre un autre RDV.','Bonjour _prenom _nom ! Votre prochain RDV chez .. est le _date @ _heure. Si vous décidez de le reporter, veuillez nous appeler au ..','Bonjour, ceci est pour confirmer le rendez-vous de _prenom _nom avec... le _date à _heure.','2024-02-04','2025-02-04','Votre compte sera bientôt en souffrance. \nDate d\'expiration 04 Février 2024. Contactez-nous au   / ',NULL,30,0);
/*!40000 ALTER TABLE `hospital_center` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importbd`
--

DROP TABLE IF EXISTS `importbd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importbd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `importDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importbd`
--

LOCK TABLES `importbd` WRITE;
/*!40000 ALTER TABLE `importbd` DISABLE KEYS */;
INSERT INTO `importbd` VALUES
(1,'/var/www/html/mydental.clinic.mydentalcloud.com/public_html/web/uploads/backup/import/mydentalBak2023-02-07.sql','2023-02-07'),
(2,'/var/www/html/mydental/web/uploads/backup/import/mydentalBak2023-03-12.sql','2023-03-12');
/*!40000 ALTER TABLE `importbd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `invoice_number` longtext DEFAULT NULL,
  `entred_date` datetime DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `remaining_amount` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_90651744A76ED395` (`user_id`),
  KEY `IDX_906517442ADD6D8C` (`supplier_id`),
  FOREIGN KEY (`supplier_id`) REFERENCES`supplier` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_prothese`
--

DROP TABLE IF EXISTS `invoice_prothese`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_prothese` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `dental_prosthesis_user_id` int(11) DEFAULT NULL,
  `invoice_number` longtext DEFAULT NULL,
  `entred_date` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `remaining_amount` double DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D11947E6A76ED395` (`user_id`),
  KEY `IDX_D11947E69227F2C2` (`dental_prosthesis_user_id`),
  FOREIGN KEY (`dental_prosthesis_user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_prothese`
--

LOCK TABLES `invoice_prothese` WRITE;
/*!40000 ALTER TABLE `invoice_prothese` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_prothese` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laboratoire_test`
--

DROP TABLE IF EXISTS `laboratoire_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laboratoire_test` (
  `id` int(11) NOT NULL,
  `measurementUnit` varchar(55) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `calculated` tinyint(1) DEFAULT NULL,
  `bilan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`test` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laboratoire_test`
--

LOCK TABLES `laboratoire_test` WRITE;
/*!40000 ALTER TABLE `laboratoire_test` DISABLE KEYS */;
INSERT INTO `laboratoire_test` VALUES
(119,'%','GB',0,NULL),
(120,'*10^9/L','lymph',0,NULL),
(121,'*10^9/L','MID',0,NULL),
(122,'*10^9/L','GRAN',0,NULL),
(123,'%','lymph',0,NULL),
(142,'g/l','HDL',0,'lipidique'),
(143,'g/L','LDL',1,'lipidique'),
(144,'MMOL/L','chlore (cl)',0,NULL),
(145,'mmol/L','Sodium Na',0,NULL),
(146,'mmol/L','Potassium K',0,NULL),
(147,'mg/l','TOTALE',0,'hépatique'),
(149,'mg/L','CALCEMIE (Ca++)',0,NULL),
(150,'g/L','Cholestérol (ch)',0,'lipidique'),
(151,'g/L','Triglycerides (TG)',0,'lipidique'),
(152,'%','Taux de prothrombine (TP)',0,NULL),
(153,'U.I/L','TGO (ASAT)',0,'hépatique'),
(154,'mg/l','DIRECTE',0,'hépatique'),
(155,'UI/ml','Facteur RH (Fr)',0,NULL),
(156,NULL,'Groupage (Grrh, Gs)',0,NULL),
(157,'ui/ml','ASLO',0,NULL),
(158,'mg/L','Acide urique (AU)',0,'rénal'),
(159,NULL,'INR',0,NULL),
(160,'µ/L','phosphatase alcaline (PAL)',0,'hépatique'),
(161,'U.I/L','LDH',0,NULL),
(162,NULL,'Chimie des urines (CU)',0,NULL),
(163,'mg/L','protéine C réactive (CRP)',0,NULL),
(164,'UI/l','TGP (ALAT)',0,'hépatique'),
(165,'Grrh','consultation+groupage',0,NULL),
(167,'MMOL/L','LAFFITTE SERIQUE',0,NULL),
(168,'mg/l','Indirecte',1,'hépatique'),
(169,'mg/l','PHOSPHORE (PH)',0,NULL),
(170,'g/l','HGPO',0,'glucidique'),
(171,'mg/l','Magnésium (MG)',0,NULL),
(172,'%','Hba1c',0,NULL),
(173,'g/l','Fibrinogène',0,NULL),
(174,NULL,'Eléctrophorèse des proteines',0,NULL),
(175,NULL,'COPROCULTURE',0,NULL),
(176,NULL,'Apolipoproteines A ou A1',0,NULL),
(177,NULL,'Immunoglibines C',0,NULL),
(178,NULL,'immunoglobines A',0,NULL),
(179,NULL,'immunoglobines B',0,NULL),
(180,NULL,'Clairance de la créatinine',0,NULL),
(181,NULL,'Electrophorèse de l\'hemoglobine',0,NULL),
(182,NULL,'HBS',0,NULL),
(183,NULL,'HBS',0,NULL),
(184,NULL,'HIV',0,NULL),
(185,NULL,'HCV',0,NULL),
(186,NULL,'HCV',0,NULL),
(187,NULL,'BW.VDRL.',0,NULL),
(188,NULL,'Waaler.rose (WR)',0,NULL),
(189,NULL,'toxoplasmose',0,NULL),
(190,NULL,'BHCG',0,NULL),
(192,NULL,'FSH',0,NULL),
(194,NULL,'LH',0,NULL),
(195,NULL,'TSH',0,NULL),
(197,NULL,'T3',0,NULL),
(201,NULL,'T4',0,NULL),
(203,'g/l','glycémie poste prandiale (Gpp)',0,'glucidique'),
(204,'g/L','Lipides totaux',1,'lipidique'),
(205,NULL,'ECBU',0,NULL),
(207,NULL,NULL,0,NULL),
(208,NULL,NULL,0,NULL),
(209,NULL,NULL,0,NULL),
(210,NULL,NULL,0,NULL),
(211,NULL,NULL,0,NULL),
(212,NULL,NULL,0,NULL),
(213,NULL,NULL,0,NULL),
(214,NULL,NULL,0,NULL),
(215,NULL,NULL,0,NULL),
(216,NULL,NULL,0,NULL),
(217,NULL,NULL,0,NULL),
(218,NULL,NULL,0,NULL),
(219,NULL,NULL,0,NULL),
(220,NULL,NULL,0,NULL),
(221,NULL,NULL,0,NULL),
(222,NULL,NULL,0,NULL),
(223,NULL,NULL,0,NULL),
(224,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `laboratoire_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_history`
--

DROP TABLE IF EXISTS `login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_37976E36A76ED395` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30260 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_history`
--

LOCK TABLES `login_history` WRITE;
/*!40000 ALTER TABLE `login_history` DISABLE KEYS */;
INSERT INTO `login_history` VALUES
(1,'2023-01-31 13:30:20','Connexion',22),
(2,'2023-01-31 15:51:39','Déconnexion',22),
(3,'2023-02-01 11:22:46','Connexion',22),
(4,'2023-02-01 11:38:25','Connexion',22),
(5,'2023-02-01 13:34:36','Connexion',22),
(6,'2023-02-03 23:07:26','Connexion',23),
(7,'2023-02-03 23:11:25','Déconnexion',23),
(30257,'2024-11-05 10:54:51','Connexion',42),
(30258,'2024-11-05 10:54:52','Connexion',42),
(30259,'2024-11-05 12:04:26','Connexion',23);
/*!40000 ALTER TABLE `login_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lot`
--

DROP TABLE IF EXISTS `lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `lot_number` varchar(255) DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `visible` int(11) DEFAULT NULL,
  `stockQte` int(11) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `picturePath` varchar(255) DEFAULT NULL,
  `pictureName` varchar(255) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `cost` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B81291B4584665A` (`product_id`),
  KEY `IDX_B81291B2ADD6D8C` (`supplier_id`),
  FOREIGN KEY (`supplier_id`) REFERENCES`supplier` (`id`),
  FOREIGN KEY (`product_id`) REFERENCES`product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lot`
--

LOCK TABLES `lot` WRITE;
/*!40000 ALTER TABLE `lot` DISABLE KEYS */;
/*!40000 ALTER TABLE `lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_personal_history`
--

DROP TABLE IF EXISTS `medical_personal_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_personal_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `allergy` longtext DEFAULT NULL,
  `medicalHistories` longtext DEFAULT NULL,
  `surgicalHistories` longtext DEFAULT NULL,
  `familysurgical` longtext DEFAULT NULL,
  `familymedical` longtext DEFAULT NULL,
  `summary` longtext DEFAULT NULL,
  `menarche` longtext DEFAULT NULL,
  `menopause` longtext DEFAULT NULL,
  `parity` longtext DEFAULT NULL,
  `gravidity` longtext DEFAULT NULL,
  `cycle` longtext DEFAULT NULL,
  `dysmenorrhea` longtext DEFAULT NULL,
  `dyspareunia` longtext DEFAULT NULL,
  `other` longtext DEFAULT NULL,
  `traumatic_histories` longtext DEFAULT NULL,
  `obstetrical_histories` longtext DEFAULT NULL,
  `initialWeight` longtext DEFAULT NULL,
  `psychiatric` longtext DEFAULT NULL,
  `toxic` longtext DEFAULT NULL,
  `prison` longtext DEFAULT NULL,
  `trauma` longtext DEFAULT NULL,
  `psychomotor_development` longtext DEFAULT NULL,
  `abundance` longtext DEFAULT NULL,
  `menstruationDuration` longtext DEFAULT NULL,
  `cesarean` longtext DEFAULT NULL,
  `abortion` longtext DEFAULT NULL,
  `contraceptionType` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11044 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_personal_history`
--

LOCK TABLES `medical_personal_history` WRITE;
/*!40000 ALTER TABLE `medical_personal_history` DISABLE KEYS */;
INSERT INTO `medical_personal_history` VALUES
(2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(11041,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(11042,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(11043,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `medical_personal_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) DEFAULT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `body` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B6BD307FE2904019` (`thread_id`),
  KEY `IDX_B6BD307FF624B39D` (`sender_id`),
  FOREIGN KEY (`thread_id`) REFERENCES`thread` (`id`),
  FOREIGN KEY (`sender_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_metadata`
--

DROP TABLE IF EXISTS `message_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) DEFAULT NULL,
  `participant_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4632F005537A1329` (`message_id`),
  KEY `IDX_4632F0059D1C3019` (`participant_id`),
  FOREIGN KEY (`message_id`) REFERENCES`message` (`id`),
  FOREIGN KEY (`participant_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_metadata`
--

LOCK TABLES `message_metadata` WRITE;
/*!40000 ALTER TABLE `message_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `normal_value`
--

DROP TABLE IF EXISTS `normal_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `normal_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `laboratoire_test_id` int(11) DEFAULT NULL,
  `upperBound` double DEFAULT NULL,
  `lowerBound` double DEFAULT NULL,
  `characteristics` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_50D0BB6E16C3F346` (`laboratoire_test_id`),
  FOREIGN KEY (`laboratoire_test_id`) REFERENCES`laboratoire_test` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `normal_value`
--

LOCK TABLES `normal_value` WRITE;
/*!40000 ALTER TABLE `normal_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `normal_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ophthalmology_consultation`
--

DROP TABLE IF EXISTS `ophthalmology_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ophthalmology_consultation` (
  `id` int(11) NOT NULL,
  `left_distance_visual_acuity_axis` varchar(255) DEFAULT NULL,
  `right_distance_visual_acuity_axis` varchar(255) DEFAULT NULL,
  `left_distance_visual_acuity_cylinder` varchar(255) DEFAULT NULL,
  `right_distance_visual_acuity_cylinder` varchar(255) DEFAULT NULL,
  `left_distance_visual_acuity_sphere` varchar(255) DEFAULT NULL,
  `right_distance_visual_acuity_sphere` varchar(255) DEFAULT NULL,
  `left_near_visual_acuity_axis` varchar(255) DEFAULT NULL,
  `right_near_visual_acuity_axis` varchar(255) DEFAULT NULL,
  `left_near_visual_acuity_cylinder` varchar(255) DEFAULT NULL,
  `right_near_visual_acuity_cylinder` varchar(255) DEFAULT NULL,
  `left_near_visual_acuity_sphere` varchar(255) DEFAULT NULL,
  `right_near_visual_acuity_sphere` varchar(255) DEFAULT NULL,
  `left_distance_correction_axis` varchar(255) DEFAULT NULL,
  `right_distance_correction_axis` varchar(255) DEFAULT NULL,
  `left_distance_correction_cylinder` varchar(255) DEFAULT NULL,
  `right_distance_correction_cylinder` varchar(255) DEFAULT NULL,
  `left_distance_correction_sphere` varchar(255) DEFAULT NULL,
  `right_distance_correction_sphere` varchar(255) DEFAULT NULL,
  `left_near_correction_axis` varchar(255) DEFAULT NULL,
  `right_near_correction_axis` varchar(255) DEFAULT NULL,
  `left_near_correction_cylinder` varchar(255) DEFAULT NULL,
  `right_near_correction_cylinder` varchar(255) DEFAULT NULL,
  `left_near_correction_sphere` varchar(255) DEFAULT NULL,
  `right_near_correction_sphere` varchar(255) DEFAULT NULL,
  `left_lens_correction_axis` varchar(255) DEFAULT NULL,
  `right_lens_correction_axis` varchar(255) DEFAULT NULL,
  `left_lens_correction_cylinder` varchar(255) DEFAULT NULL,
  `right_lens_correction_cylinder` varchar(255) DEFAULT NULL,
  `left_lens_correction_sphere` varchar(255) DEFAULT NULL,
  `right_lens_correction_sphere` varchar(255) DEFAULT NULL,
  `left_lens_correction_ro` varchar(255) DEFAULT NULL,
  `right_lens_correction_ro` varchar(255) DEFAULT NULL,
  `left_lens_correction_diam` varchar(255) DEFAULT NULL,
  `right_lens_correction_diam` varchar(255) DEFAULT NULL,
  `left_laf` varchar(255) DEFAULT NULL,
  `right_laf` varchar(255) DEFAULT NULL,
  `left_to` varchar(255) DEFAULT NULL,
  `right_to` varchar(255) DEFAULT NULL,
  `pupillary_Distance` varchar(255) DEFAULT NULL,
  `glass_type` varchar(255) DEFAULT NULL,
  `lens_type` varchar(255) DEFAULT NULL,
  `left_papille` varchar(255) DEFAULT NULL,
  `right_papille` varchar(255) DEFAULT NULL,
  `left_macula` varchar(255) DEFAULT NULL,
  `right_macula` varchar(255) DEFAULT NULL,
  `left_periphery` varchar(255) DEFAULT NULL,
  `right_periphery` varchar(255) DEFAULT NULL,
  `left_distance_visual_acuity` varchar(255) DEFAULT NULL,
  `right_distance_visual_acuity` varchar(255) DEFAULT NULL,
  `left_distance_visual_acuityAC` varchar(255) DEFAULT NULL,
  `right_distance_visual_acuityAC` varchar(255) DEFAULT NULL,
  `cycloplegic` varchar(255) DEFAULT NULL,
  `addition` varchar(255) DEFAULT NULL,
  `left_kerato1` varchar(255) DEFAULT NULL,
  `right_kerato1` varchar(255) DEFAULT NULL,
  `left_kerato2` varchar(255) DEFAULT NULL,
  `right_kerato2` varchar(255) DEFAULT NULL,
  `left_radius0` varchar(255) DEFAULT NULL,
  `right_radius0` varchar(255) DEFAULT NULL,
  `left_radius1` varchar(255) DEFAULT NULL,
  `right_radius1` varchar(255) DEFAULT NULL,
  `left_radius2` varchar(255) DEFAULT NULL,
  `right_radius2` varchar(255) DEFAULT NULL,
  `right_pachy` varchar(255) DEFAULT NULL,
  `left_pachy` varchar(255) DEFAULT NULL,
  `right_toc` varchar(255) DEFAULT NULL,
  `left_toc` varchar(255) DEFAULT NULL,
  `left_near_vision` varchar(255) DEFAULT NULL,
  `right_near_vision` varchar(255) DEFAULT NULL,
  `left_distance_vision` varchar(255) DEFAULT NULL,
  `right_distance_vision` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ophthalmology_consultation`
--

LOCK TABLES `ophthalmology_consultation` WRITE;
/*!40000 ALTER TABLE `ophthalmology_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ophthalmology_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orl_consultation`
--

DROP TABLE IF EXISTS `orl_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orl_consultation` (
  `id` int(11) NOT NULL,
  `disease_history` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orl_consultation`
--

LOCK TABLES `orl_consultation` WRITE;
/*!40000 ALTER TABLE `orl_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `orl_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orthodontic_consultation`
--

DROP TABLE IF EXISTS `orthodontic_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orthodontic_consultation` (
  `id` int(11) NOT NULL,
  `phase` varchar(50) DEFAULT NULL,
  `maxillary` varchar(50) DEFAULT NULL,
  `ring_type_top` varchar(50) DEFAULT NULL,
  `ring_type_bottom` varchar(50) DEFAULT NULL,
  `tim` varchar(50) DEFAULT NULL,
  `turbo_bites` varchar(50) DEFAULT NULL,
  `bracket_top` varchar(50) DEFAULT NULL,
  `bracket_bottom` varchar(50) DEFAULT NULL,
  `extractions_treatment_plan` longtext DEFAULT NULL,
  `stripping` tinyint(1) DEFAULT NULL,
  `other_treatment_plan` longtext DEFAULT NULL,
  `a_p_sens` varchar(50) DEFAULT NULL,
  `vertical_sens` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `transversal_sens` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `d_a_m` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `problem` longtext DEFAULT NULL,
  `extractions_diag` longtext DEFAULT NULL,
  `current_acts` longtext DEFAULT NULL,
  `next_acts` longtext DEFAULT NULL,
  `device_type` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `device_type_invisalign` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `other_device_invisalign` longtext DEFAULT NULL COMMENT '(DC2Type:array)',
  `maxillary_invisalign` varchar(50) DEFAULT NULL,
  `extractions_invisalign` longtext DEFAULT NULL,
  `other_invisalign` longtext DEFAULT NULL,
  `type_ortho` varchar(50) DEFAULT NULL,
  `tooth_number` varchar(50) DEFAULT NULL,
  `dental_care_note` longtext DEFAULT NULL,
  `dental_prosthesis_tooth_number` varchar(50) DEFAULT NULL,
  `dental_prosthesis_note` longtext DEFAULT NULL,
  `dental_surgery_tooth_number` varchar(50) DEFAULT NULL,
  `dental_surgery_note` longtext DEFAULT NULL,
  `dental_implant_note` longtext DEFAULT NULL,
  `dental_implant_tooth_number` varchar(50) DEFAULT NULL,
  `dental_implant_diameter` varchar(50) DEFAULT NULL,
  `dental_implant_length` varchar(50) DEFAULT NULL,
  `dental_implant_correction` varchar(50) DEFAULT NULL,
  `dental_prosthesis_type` varchar(150) DEFAULT NULL,
  `dental_prosthesis_lab_price` varchar(50) DEFAULT NULL,
  `dental_implant_brand` varchar(150) DEFAULT NULL,
  `dental_implant_model` varchar(150) DEFAULT NULL,
  `dental_implant_lab_price` varchar(50) DEFAULT NULL,
  `treatment_plan` longtext DEFAULT NULL,
  `diagnosis` longtext DEFAULT NULL,
  `note_consult` longtext DEFAULT NULL,
  `dental_care_diag` longtext DEFAULT NULL,
  `dental_prosthesis_diag` longtext DEFAULT NULL,
  `dental_surgery_diag` longtext DEFAULT NULL,
  `dental_implant_diag` longtext DEFAULT NULL,
  `dental_paro_note` longtext DEFAULT NULL,
  `dental_paro_diag` longtext DEFAULT NULL,
  `dental_prosthesis_user_id` int(11) DEFAULT NULL,
  `prosthesis_note` longtext DEFAULT NULL,
  `dental_implant_impression_type` varchar(150) DEFAULT NULL,
  `dental_prosthesis_clinical_stage_id` int(11) DEFAULT NULL,
  `dental_prosthesis_lab_state_id` int(11) DEFAULT NULL,
  `dental_prosthesis_end_date` datetime DEFAULT NULL,
  `dental_implant_type` varchar(150) DEFAULT NULL,
  `dental_implant_clinical_stage_id` int(11) DEFAULT NULL,
  `dental_implant_lab_state_id` int(11) DEFAULT NULL,
  `dental_prosthesis_status` tinyint(1) DEFAULT NULL,
  `dental_prosthesis_lab_status` varchar(50) DEFAULT NULL,
  `dental_prosthesis_start_date` datetime DEFAULT NULL,
  `dental_ortho_lab_state_id` int(11) DEFAULT NULL,
  `dental_ortho_lab_price` varchar(50) DEFAULT NULL,
  `dental_prosthesis_ortho_user_id` int(11) DEFAULT NULL,
  `dental_prosthesis_implant_user_id` int(11) DEFAULT NULL,
  `dental_ortho_impression_type` varchar(150) DEFAULT NULL,
  `dental_prosthesis_impression_type` varchar(150) DEFAULT NULL,
  `dental_ortho_prosthesis_status` tinyint(1) DEFAULT NULL,
  `dental_implant_prosthesis_status` tinyint(1) DEFAULT NULL,
  `prosthesis_note_ortho` longtext DEFAULT NULL,
  `prosthesis_note_implant` longtext DEFAULT NULL,
  `note_radio` longtext DEFAULT NULL,
  `invoice_prothese_id` int(11) DEFAULT NULL,
  `doc_note_proth_for_prosthesis` longtext DEFAULT NULL,
  `doc_note_ortho_for_prosthesis` longtext DEFAULT NULL,
  `doc_note_implant_for_prosthesis` longtext DEFAULT NULL,
  `new_doc_proth_note` tinyint(1) DEFAULT NULL,
  `new_doc_ortho_note` tinyint(1) DEFAULT NULL,
  `new_doc_implant_note` tinyint(1) DEFAULT NULL,
  `doc_proth_note_checked` tinyint(1) DEFAULT NULL,
  `doc_ortho_note_checked` tinyint(1) DEFAULT NULL,
  `doc_implant_note_checked` tinyint(1) DEFAULT NULL,
  `note_checked` tinyint(1) DEFAULT NULL,
  `new_prosthesis_note` tinyint(1) DEFAULT NULL,
  `dental_aesthetic_tooth_number` varchar(50) DEFAULT NULL,
  `dental_Aesthetic_note` longtext DEFAULT NULL,
  `dental_Aesthetic_diag` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7C8DFE1E9227F2C2` (`dental_prosthesis_user_id`),
  KEY `IDX_7C8DFE1E604830AA` (`dental_prosthesis_clinical_stage_id`),
  KEY `IDX_7C8DFE1E9013B825` (`dental_prosthesis_lab_state_id`),
  KEY `IDX_7C8DFE1E74A20D36` (`dental_implant_clinical_stage_id`),
  KEY `IDX_7C8DFE1E4CEA3514` (`dental_implant_lab_state_id`),
  KEY `IDX_7C8DFE1E1EF90924` (`dental_ortho_lab_state_id`),
  KEY `IDX_7C8DFE1E7E059EB4` (`dental_prosthesis_ortho_user_id`),
  KEY `IDX_7C8DFE1E7D9455D2` (`dental_prosthesis_implant_user_id`),
  KEY `IDX_7C8DFE1E107D18F1` (`invoice_prothese_id`),
  FOREIGN KEY (`invoice_prothese_id`) REFERENCES`invoice_prothese` (`id`),
  FOREIGN KEY (`dental_ortho_lab_state_id`) REFERENCES`status` (`id`),
  FOREIGN KEY (`dental_implant_lab_state_id`) REFERENCES`status` (`id`),
  FOREIGN KEY (`dental_prosthesis_clinical_stage_id`) REFERENCES`status` (`id`),
  FOREIGN KEY (`dental_implant_clinical_stage_id`) REFERENCES`status` (`id`),
  FOREIGN KEY (`dental_prosthesis_implant_user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`dental_prosthesis_ortho_user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`dental_prosthesis_lab_state_id`) REFERENCES`status` (`id`),
  FOREIGN KEY (`dental_prosthesis_user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orthodontic_consultation`
--

LOCK TABLES `orthodontic_consultation` WRITE;
/*!40000 ALTER TABLE `orthodontic_consultation` DISABLE KEYS */;
INSERT INTO `orthodontic_consultation` VALUES
(2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'a:0:{}','a:0:{}','a:0:{}',NULL,NULL,NULL,NULL,'a:0:{}','a:0:{}','a:0:{}',NULL,NULL,NULL,'Ortho',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','0',NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,0,'Non réglé',NULL,NULL,'0',NULL,NULL,'','',0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,0,NULL,NULL,NULL),

(32719,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'a:0:{}','a:0:{}','a:0:{}',NULL,NULL,NULL,NULL,'N;','N;','N;',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Non réglé',NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,0,NULL,NULL,NULL),
(32720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'a:0:{}','a:0:{}','a:0:{}',NULL,NULL,NULL,NULL,'N;','N;','N;',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','0',NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,0,'Non réglé',NULL,NULL,'0',NULL,NULL,'','',0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,0,NULL,NULL,NULL),
(32721,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'a:0:{}','a:0:{}','a:0:{}',NULL,NULL,NULL,NULL,'N;','N;','N;',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','0',NULL,NULL,'0','Dent 11 :  Obturation au composite; \r\nDent 13 :  Traitement endo sur mono; \r\nDent 16 :  Exo; \r\nDent 17 :  Exo; \r\nDent 21 :  Obturation au composite; \r\nDent 22 :  Obturation au composite; \r\nDent 23 :  Traitement endo sur mono; \r\nDent 24 :  Traitement endo sur mono; \r\nDent 26 :  Traitement endo sur pluri; \r\nDent 36 :  Exo; \r\nDent 37 :  Exo; \r\nDent 47 :  Traitement endo sur pluri; \r\nDent 48 :  Exo DDS; \r\nDent 100 :  Detartrage;',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,0,'Non réglé',NULL,NULL,'0',NULL,NULL,'','',0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,0,NULL,NULL,NULL),
(32722,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'a:0:{}','a:0:{}','a:0:{}',NULL,NULL,NULL,NULL,'N;','N;','N;',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','0',NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,0,'Non réglé',NULL,NULL,'0',NULL,NULL,'','',0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,0,NULL,NULL,NULL),
(32723,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'a:0:{}','a:0:{}','a:0:{}',NULL,NULL,NULL,NULL,'N;','N;','N;',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','0',NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,0,'Non réglé',NULL,NULL,'0',NULL,NULL,'','',0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `orthodontic_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orthodontic_consultation_dentalAesthetic`
--

DROP TABLE IF EXISTS `orthodontic_consultation_dentalAesthetic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orthodontic_consultation_dentalAesthetic` (
  `orthodontic_consultation_id` int(11) NOT NULL,
  `udc_id` int(11) NOT NULL,
  PRIMARY KEY (`orthodontic_consultation_id`,`udc_id`),
  KEY `IDX_1E3163FA69CF7898` (`orthodontic_consultation_id`),
  KEY `IDX_1E3163FA360CA893` (`udc_id`),
  FOREIGN KEY (`udc_id`) REFERENCES`udc` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`orthodontic_consultation_id`) REFERENCES`orthodontic_consultation` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orthodontic_consultation_dentalAesthetic`
--

LOCK TABLES `orthodontic_consultation_dentalAesthetic` WRITE;
/*!40000 ALTER TABLE `orthodontic_consultation_dentalAesthetic` DISABLE KEYS */;
/*!40000 ALTER TABLE `orthodontic_consultation_dentalAesthetic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orthodontic_consultation_dentalcare`
--

DROP TABLE IF EXISTS `orthodontic_consultation_dentalcare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orthodontic_consultation_dentalcare` (
  `orthodontic_consultation_id` int(11) NOT NULL,
  `udc_id` int(11) NOT NULL,
  PRIMARY KEY (`orthodontic_consultation_id`,`udc_id`),
  KEY `IDX_729010AA69CF7898` (`orthodontic_consultation_id`),
  KEY `IDX_729010AA360CA893` (`udc_id`),
  FOREIGN KEY (`udc_id`) REFERENCES`udc` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`orthodontic_consultation_id`) REFERENCES`orthodontic_consultation` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orthodontic_consultation_dentalcare`
--

LOCK TABLES `orthodontic_consultation_dentalcare` WRITE;
/*!40000 ALTER TABLE `orthodontic_consultation_dentalcare` DISABLE KEYS */;
/*!40000 ALTER TABLE `orthodontic_consultation_dentalcare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orthodontic_consultation_implant`
--

DROP TABLE IF EXISTS `orthodontic_consultation_implant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orthodontic_consultation_implant` (
  `orthodontic_consultation_id` int(11) NOT NULL,
  `udc_id` int(11) NOT NULL,
  PRIMARY KEY (`orthodontic_consultation_id`,`udc_id`),
  KEY `IDX_ED3DB98B69CF7898` (`orthodontic_consultation_id`),
  KEY `IDX_ED3DB98B360CA893` (`udc_id`),
  FOREIGN KEY (`udc_id`) REFERENCES`udc` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`orthodontic_consultation_id`) REFERENCES`orthodontic_consultation` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orthodontic_consultation_implant`
--

LOCK TABLES `orthodontic_consultation_implant` WRITE;
/*!40000 ALTER TABLE `orthodontic_consultation_implant` DISABLE KEYS */;
/*!40000 ALTER TABLE `orthodontic_consultation_implant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orthodontic_consultation_prosthesis`
--

DROP TABLE IF EXISTS `orthodontic_consultation_prosthesis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orthodontic_consultation_prosthesis` (
  `orthodontic_consultation_id` int(11) NOT NULL,
  `udc_id` int(11) NOT NULL,
  PRIMARY KEY (`orthodontic_consultation_id`,`udc_id`),
  KEY `IDX_FCFBEC4F69CF7898` (`orthodontic_consultation_id`),
  KEY `IDX_FCFBEC4F360CA893` (`udc_id`),
  FOREIGN KEY (`udc_id`) REFERENCES`udc` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`orthodontic_consultation_id`) REFERENCES`orthodontic_consultation` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orthodontic_consultation_prosthesis`
--

LOCK TABLES `orthodontic_consultation_prosthesis` WRITE;
/*!40000 ALTER TABLE `orthodontic_consultation_prosthesis` DISABLE KEYS */;
/*!40000 ALTER TABLE `orthodontic_consultation_prosthesis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orthodontic_consultation_surgery`
--

DROP TABLE IF EXISTS `orthodontic_consultation_surgery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orthodontic_consultation_surgery` (
  `orthodontic_consultation_id` int(11) NOT NULL,
  `udc_id` int(11) NOT NULL,
  PRIMARY KEY (`orthodontic_consultation_id`,`udc_id`),
  KEY `IDX_F318A7A069CF7898` (`orthodontic_consultation_id`),
  KEY `IDX_F318A7A0360CA893` (`udc_id`),
  FOREIGN KEY (`udc_id`) REFERENCES`udc` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`orthodontic_consultation_id`) REFERENCES`orthodontic_consultation` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orthodontic_consultation_surgery`
--

LOCK TABLES `orthodontic_consultation_surgery` WRITE;
/*!40000 ALTER TABLE `orthodontic_consultation_surgery` DISABLE KEYS */;
/*!40000 ALTER TABLE `orthodontic_consultation_surgery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medical_personal_history_id` int(11) DEFAULT NULL,
  `lastName` varchar(150) NOT NULL,
  `firstName` varchar(150) NOT NULL,
  `birthDate` date NOT NULL,
  `birthPlace` varchar(155) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gender` varchar(70) DEFAULT NULL,
  `phone` varchar(55) DEFAULT NULL,
  `numCartechifae` varchar(20) DEFAULT NULL,
  `familyStatus` varchar(25) DEFAULT NULL,
  `EmergencyPhone` varchar(55) DEFAULT NULL,
  `traitingDoctor` varchar(255) DEFAULT NULL,
  `bloodGroup` varchar(25) DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `origin` varchar(255) DEFAULT NULL,
  `NbPrintCard` int(11) DEFAULT NULL,
  `referencedBy` varchar(155) DEFAULT NULL,
  `husbandsName` varchar(150) DEFAULT NULL,
  `characteristics` varchar(255) DEFAULT NULL,
  `cat1` varchar(255) DEFAULT NULL,
  `cat2` varchar(255) DEFAULT NULL,
  `cat3` varchar(255) DEFAULT NULL,
  `cat4` varchar(255) DEFAULT NULL,
  `cat5` varchar(255) DEFAULT NULL,
  `fax` varchar(55) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `picturePath` varchar(255) DEFAULT NULL,
  `pictureName` varchar(255) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `smsConfirmation` int(11) DEFAULT NULL,
  `emailConfirmation` int(11) DEFAULT NULL,
  `user_created_id` int(11) DEFAULT NULL,
  `arabic_last_name` varchar(250) DEFAULT NULL,
  `arabic_first_name` varchar(250) DEFAULT NULL,
  `converted` tinyint(1) DEFAULT NULL,
  `convertedDate` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_1ADAD7EB690821EB` (`medical_personal_history_id`),
  KEY `IDX_1ADAD7EB87F4FB17` (`doctor_id`),
  KEY `IDX_1ADAD7EBF987D8A8` (`user_created_id`),
  FOREIGN KEY (`medical_personal_history_id`) REFERENCES`medical_personal_history` (`id`),
  FOREIGN KEY (`doctor_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11793 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES
(2,2,'MARTIN','MARIE','1900-01-01',NULL,'New City','Feminin','0797156996',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'traitement d urgence 36 sr',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,24,1,1,24,'','',0,NULL),
(3,3,'BERNARD','STECY','1900-01-01',NULL,'New City','Feminin','0698342901',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,24,1,1,24,'','',0,NULL),
(11790,11041,'GARCIN','MARTHE','1978-02-08',NULL,'New City','Feminin','0653722223',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,29,'','',0,NULL),
(11791,11042,'RAVON','SERGDIANA','2004-12-01',NULL,'New City','Feminin','0796616839',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,29,'','',0,NULL),
(11792,11043,'WISNIEWSKI','ELODIE','1971-08-19',NULL,'New City','Feminin','0771597595',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,29,'','',0,NULL);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_service_event`
--

DROP TABLE IF EXISTS `patient_service_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_service_event` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `basic_visit_id` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `validation` varchar(55) DEFAULT NULL,
  `user_taking_id` int(11) DEFAULT NULL,
  `user_modifying_id` int(11) DEFAULT NULL,
  `dateTaking` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_535BA9B46B899279` (`patient_id`),
  KEY `IDX_535BA9B4E85EF78F` (`user_taking_id`),
  KEY `IDX_535BA9B4FF785E62` (`user_modifying_id`),
  FOREIGN KEY (`patient_id`) REFERENCES`patient` (`id`),
  FOREIGN KEY (`id`) REFERENCES`evenement` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_taking_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`user_modifying_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_service_event`
--

LOCK TABLES `patient_service_event` WRITE;
/*!40000 ALTER TABLE `patient_service_event` DISABLE KEYS */;
INSERT INTO `patient_service_event` VALUES
(1,10,'0','489_consultation',NULL,29,NULL,'2023-02-04 09:58:25'),
(3,13,'0','245_controle',NULL,29,NULL,'2023-02-04 10:09:50'),

(17537,11329,'0','',NULL,29,NULL,'2024-11-04 16:43:57'),
(17538,10663,'0','',NULL,29,NULL,'2024-11-04 17:12:10'),
(17539,11560,'0','',NULL,29,NULL,'2024-11-04 18:07:34'),
(17540,11784,'0','',NULL,29,NULL,'2024-11-04 22:29:10'),
(17541,11748,'0','','Confirmé',29,29,'2024-11-05 08:52:28'),
(17542,8259,'0','',NULL,29,NULL,'2024-11-05 09:53:48'),
(17543,10486,'0','',NULL,29,NULL,'2024-11-05 10:06:54'),
(17544,11257,'0','',NULL,29,NULL,'2024-11-05 10:31:20'),
(17545,11791,'0','',NULL,29,NULL,'2024-11-05 10:54:47'),
(17546,1224,'0','',NULL,29,NULL,'2024-11-05 11:23:34'),
(17547,6851,'0','',NULL,29,NULL,'2024-11-05 11:42:29'),
(17548,11458,'0','',NULL,29,NULL,'2024-11-05 12:03:41');
/*!40000 ALTER TABLE `patient_service_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_user_event`
--

DROP TABLE IF EXISTS `patient_user_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_user_event` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sms_id` int(11) DEFAULT NULL,
  `smsSent` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6FAC5710A76ED395` (`user_id`),
  KEY `IDX_6FAC5710BD5C7E60` (`sms_id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`sms_id`) REFERENCES`sms` (`id`),
  FOREIGN KEY (`id`) REFERENCES`evenement` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_user_event`
--

LOCK TABLES `patient_user_event` WRITE;
/*!40000 ALTER TABLE `patient_user_event` DISABLE KEYS */;
INSERT INTO `patient_user_event` VALUES
(1,25,NULL,0),
(3,26,NULL,0),
(4,27,NULL,0),

(17543,27,NULL,0),
(17544,38,NULL,0),
(17545,35,NULL,0),
(17546,27,NULL,0),
(17547,41,NULL,0),
(17548,31,NULL,0);
/*!40000 ALTER TABLE `patient_user_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) DEFAULT NULL,
  `starting_price` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `remaining_amount` double DEFAULT NULL,
  `convention_id` int(11) DEFAULT NULL,
  `payment_type` varchar(80) DEFAULT NULL,
  `discount_reason` varchar(255) DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6D28840D62FF6CDF` (`consultation_id`),
  KEY `IDX_6D28840DA2ACEBCC` (`convention_id`),
  FOREIGN KEY (`consultation_id`) REFERENCES`consultation` (`id`),
  FOREIGN KEY (`convention_id`) REFERENCES`convention` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=218687 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES
(9,2,40,40,0,40,'1',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(10,2,0,0,0,0,'10',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(11,2,0,0,0,0,'6',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(12,2,0,0,0,0,'9',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(13,2,0,0,0,0,'7',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(14,2,0,0,0,0,'2',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(15,2,0,0,0,0,'3',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(16,2,0,0,0,0,'4',0,NULL,'Espèces','/',0,'2023-02-03 23:35:39'),
(218669,32719,0,-100,0,0,'1',-100,NULL,'Espèces','/',0,'2024-11-05 11:45:42'),
(218670,32719,0,-1300,0,0,'2',-1300,NULL,'Espèces','/',0,'2024-11-05 11:45:42'),
(218671,32717,60,60,0,60,'1',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218672,32717,0,0,0,0,'10',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218673,32717,20,20,0,20,'6',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218674,32717,0,0,0,0,'9',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218675,32717,0,0,0,0,'7',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218676,32717,0,0,0,0,'2',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218677,32717,0,0,0,0,'3',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218678,32717,0,0,0,0,'4',0,NULL,'Espèces','/',0,'2024-11-05 11:49:53'),
(218679,32711,160,160,1000,140,'1',0,NULL,'Espèces',NULL,12.5,'2024-11-05 12:04:20'),
(218680,32711,0,0,0,0,'10',0,NULL,'Espèces','/',0,'2024-11-05 12:04:20'),
(218681,32711,0,0,0,0,'6',0,NULL,'Espèces','/',0,'2024-11-05 12:04:20'),
(218682,32711,0,0,0,0,'9',0,NULL,'Espèces','/',0,'2024-11-05 12:04:20'),
(218683,32711,0,0,0,0,'7',0,NULL,'Espèces','/',0,'2024-11-05 12:04:20'),
(218684,32711,0,0,0,0,'2',0,NULL,'Espèces','/',0,'2024-11-05 12:04:20'),
(218685,32711,0,0,0,0,'3',0,NULL,'Espèces','/',0,'2024-11-05 12:04:20'),
(218686,32711,0,0,0,0,'4',0,NULL,'Espèces','/',0,'2024-11-05 12:04:20');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_history`
--

DROP TABLE IF EXISTS `payment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `idudc` int(11) DEFAULT NULL,
  `description1` longtext DEFAULT NULL,
  `value` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3EF37EA175FA0FF2` (`visit_id`),
  FOREIGN KEY (`visit_id`) REFERENCES`visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23642 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_history`
--

LOCK TABLES `payment_history` WRITE;
/*!40000 ALTER TABLE `payment_history` DISABLE KEYS */;
INSERT INTO `payment_history` VALUES
(3,2,485,'Traitement endo sur pluri','240'),
(4,2,1079,'Traitement d\'urgence','40'),
(5,3,482,'Exo complex','40'),
(6,4,1079,'Traitement d\'urgence','40'),
(7,5,481,'Exo','30'),
(8,6,1079,'Traitement d\'urgence','40'),
(23633,32701,483,'Obturation au composite','80'),
(23634,32715,489,'consultation','20'),
(23635,32710,481,'Exo','60'),
(23636,32710,489,'consultation','20'),
(23637,32707,159,'Couronne Zircon','700'),
(23639,32717,481,'Exo','60'),
(23640,32717,489,'consultation','20'),
(23641,32711,483,'Obturation au composite','80');
/*!40000 ALTER TABLE `payment_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_invoice`
--

DROP TABLE IF EXISTS `payment_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `entred_date` datetime DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_892C19AEA76ED395` (`user_id`),
  KEY `IDX_892C19AE2989F1FD` (`invoice_id`),
  FOREIGN KEY (`invoice_id`) REFERENCES`invoice` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_invoice`
--

LOCK TABLES `payment_invoice` WRITE;
/*!40000 ALTER TABLE `payment_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_invoice_prothese`
--

DROP TABLE IF EXISTS `payment_invoice_prothese`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_invoice_prothese` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `invoice_prothese_id` int(11) DEFAULT NULL,
  `entred_date` datetime DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9EC13D58A76ED395` (`user_id`),
  KEY `IDX_9EC13D58107D18F1` (`invoice_prothese_id`),
  FOREIGN KEY (`invoice_prothese_id`) REFERENCES`invoice_prothese` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_invoice_prothese`
--

LOCK TABLES `payment_invoice_prothese` WRITE;
/*!40000 ALTER TABLE `payment_invoice_prothese` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_invoice_prothese` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physiotherapy_consultation`
--

DROP TABLE IF EXISTS `physiotherapy_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physiotherapy_consultation` (
  `id` int(11) NOT NULL,
  `precaution` longtext DEFAULT NULL,
  `type_visit` varchar(150) DEFAULT NULL,
  `cryotherapie` tinyint(1) DEFAULT NULL,
  `cryotherapie_duree` time DEFAULT NULL,
  `cryotherapie_note` longtext DEFAULT NULL,
  `infrarouge` tinyint(1) DEFAULT NULL,
  `infrarouge_duree` time DEFAULT NULL,
  `infrarouge_note` longtext DEFAULT NULL,
  `compresse_chaude` tinyint(1) DEFAULT NULL,
  `compresse_chaude_duree` time DEFAULT NULL,
  `compresse_chaude_note` longtext DEFAULT NULL,
  `electrotherapie_antalgique` tinyint(1) DEFAULT NULL,
  `electrotherapie_antalgique_duree` time DEFAULT NULL,
  `electrotherapie_antalgique_note` longtext DEFAULT NULL,
  `electro_stimulation` tinyint(1) DEFAULT NULL,
  `electro_stimulation_duree` time DEFAULT NULL,
  `electro_stimulation_note` longtext DEFAULT NULL,
  `ultrason` tinyint(1) DEFAULT NULL,
  `ultrason_duree` time DEFAULT NULL,
  `ultrason_note` longtext DEFAULT NULL,
  `mobilisation_active` tinyint(1) DEFAULT NULL,
  `mobilisation_active_duree` time DEFAULT NULL,
  `mobilisation_active_note` longtext DEFAULT NULL,
  `mobilisation_passive` tinyint(1) DEFAULT NULL,
  `mobilisation_passive_duree` time DEFAULT NULL,
  `mobilisation_passive_note` longtext DEFAULT NULL,
  `posture` tinyint(1) DEFAULT NULL,
  `posture_duree` time DEFAULT NULL,
  `posture_note` longtext DEFAULT NULL,
  `manual_therapy` tinyint(1) DEFAULT NULL,
  `manual_therapy_duree` time DEFAULT NULL,
  `manual_therapy_note` longtext DEFAULT NULL,
  `ergotherapy` tinyint(1) DEFAULT NULL,
  `ergotherapy_duree` time DEFAULT NULL,
  `ergotherapy_note` longtext DEFAULT NULL,
  `perineal_rehabilitation` tinyint(1) DEFAULT NULL,
  `perineal_rehabilitation_duree` time DEFAULT NULL,
  `perineal_rehabilitation_note` longtext DEFAULT NULL,
  `perineal_electro_stimulation` tinyint(1) DEFAULT NULL,
  `perineal_electro_stimulation_duree` time DEFAULT NULL,
  `perineal_electro_stimulation_note` longtext DEFAULT NULL,
  `biofeedback` tinyint(1) DEFAULT NULL,
  `biofeedback_duree` time DEFAULT NULL,
  `biofeedback_note` longtext DEFAULT NULL,
  `podiatry` tinyint(1) DEFAULT NULL,
  `podiatry_duree` time DEFAULT NULL,
  `podiatry_note` longtext DEFAULT NULL,
  `kinesio_taping` tinyint(1) DEFAULT NULL,
  `kinesio_taping_duree` time DEFAULT NULL,
  `kinesio_taping_note` longtext DEFAULT NULL,
  `pressotherapie_accessoire` tinyint(1) DEFAULT NULL,
  `pressotherapie_accessoire_choice` varchar(255) DEFAULT NULL,
  `pressotherapie_accessoire_note` longtext DEFAULT NULL,
  `pression` tinyint(1) DEFAULT NULL,
  `pression_duree` time DEFAULT NULL,
  `pression_note` longtext DEFAULT NULL,
  `decompression` tinyint(1) DEFAULT NULL,
  `decompression_duree` time DEFAULT NULL,
  `decompression_note` longtext DEFAULT NULL,
  `observation` longtext DEFAULT NULL,
  `compression` tinyint(1) DEFAULT NULL,
  `compression_duree` time DEFAULT NULL,
  `physiotherapie` tinyint(1) DEFAULT NULL,
  `physiotherapie_duree` time DEFAULT NULL,
  `physiotherapie_note` longtext DEFAULT NULL,
  `kinesitherapie` tinyint(1) DEFAULT NULL,
  `kinesitherapie_duree` time DEFAULT NULL,
  `kinesitherapie_note` longtext DEFAULT NULL,
  `therapiemanuelle` tinyint(1) DEFAULT NULL,
  `therapiemanuelle_duree` time DEFAULT NULL,
  `therapiemanuelle_note` longtext DEFAULT NULL,
  `ergotherapie` tinyint(1) DEFAULT NULL,
  `ergotherapie_duree` time DEFAULT NULL,
  `ergotherapie_note` longtext DEFAULT NULL,
  `pressotherapie` tinyint(1) DEFAULT NULL,
  `pressotherapie_duree` time DEFAULT NULL,
  `pressotherapie_note` longtext DEFAULT NULL,
  `reeducationperineale` tinyint(1) DEFAULT NULL,
  `reeducationperineale_duree` time DEFAULT NULL,
  `reeducationperineale_note` longtext DEFAULT NULL,
  `kinerespiratoire` tinyint(1) DEFAULT NULL,
  `kinerespiratoire_duree` time DEFAULT NULL,
  `kinerespiratoire_note` longtext DEFAULT NULL,
  `kinesiotaping` tinyint(1) DEFAULT NULL,
  `kinesiotaping_duree` time DEFAULT NULL,
  `kinesiotaping_note` longtext DEFAULT NULL,
  `cupping_therapy` longtext DEFAULT NULL,
  `acupuncture` longtext DEFAULT NULL,
  `auriculotherapy` longtext DEFAULT NULL,
  `evaluation` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physiotherapy_consultation`
--

LOCK TABLES `physiotherapy_consultation` WRITE;
/*!40000 ALTER TABLE `physiotherapy_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `physiotherapy_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pregnancy`
--

DROP TABLE IF EXISTS `pregnancy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pregnancy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medical_personal_history_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `delivery` varchar(255) DEFAULT NULL,
  `sex` varchar(90) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `obs` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B47853AA690821EB` (`medical_personal_history_id`),
  FOREIGN KEY (`medical_personal_history_id`) REFERENCES`medical_personal_history` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pregnancy`
--

LOCK TABLES `pregnancy` WRITE;
/*!40000 ALTER TABLE `pregnancy` DISABLE KEYS */;
/*!40000 ALTER TABLE `pregnancy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `discr` varchar(255) NOT NULL,
  `drug_id` int(11) DEFAULT NULL,
  `prescription_date` datetime NOT NULL,
  `body` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1FBFB8D987F4FB17` (`doctor_id`),
  KEY `IDX_1FBFB8D9AABCA765` (`drug_id`),
  FOREIGN KEY (`doctor_id`) REFERENCES`doctor` (`id`),
  FOREIGN KEY (`drug_id`) REFERENCES`drug` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=620 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription`
--

LOCK TABLES `prescription` WRITE;
/*!40000 ALTER TABLE `prescription` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescription_type`
--

DROP TABLE IF EXISTS `prescription_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_type` (
  `id` int(11) NOT NULL,
  `prescription_type_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`prescription` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription_type`
--

LOCK TABLES `prescription_type` WRITE;
/*!40000 ALTER TABLE `prescription_type` DISABLE KEYS */;
INSERT INTO `prescription_type` VALUES
(83,'001'),
(85,'002'),
(89,'Femme Enceinte'),
(96,'ABCES'),
(103,'Essaie'),
(108,'ATARAX'),
(118,'Enfant'),
(122,'Antibiotherapie'),
(135,')'),
(149,'chirurgie'),
(177,'enfant 2'),
(187,'perfalgan'),
(191,'abces nouri'),
(193,'desmodontite'),
(223,'1'),
(344,'j');
/*!40000 ALTER TABLE `prescription_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `denomination` varchar(255) DEFAULT NULL,
  `form` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `affectation` varchar(255) DEFAULT NULL,
  `stock_threshold` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `stockQte` int(11) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `expirationDaysFlag` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `denomination_idx` (`denomination`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_log`
--

DROP TABLE IF EXISTS `product_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `action_date` datetime DEFAULT NULL,
  `action_time` datetime DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `denomination` varchar(255) DEFAULT NULL,
  `stockQte` int(11) DEFAULT NULL,
  `stockQteOld` int(11) DEFAULT NULL,
  `productPrice` double DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `remaining_amount` double DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `remaining_batch_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6F103CDAA76ED395` (`user_id`),
  KEY `IDX_6F103CDA87F4FB17` (`doctor_id`),
  KEY `IDX_6F103CDA6B899279` (`patient_id`),
  KEY `IDX_6F103CDA4584665A` (`product_id`),
  FOREIGN KEY (`product_id`) REFERENCES`product` (`id`),
  FOREIGN KEY (`patient_id`) REFERENCES`patient` (`id`),
  FOREIGN KEY (`doctor_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_log`
--

LOCK TABLES `product_log` WRITE;
/*!40000 ALTER TABLE `product_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radio_test`
--

DROP TABLE IF EXISTS `radio_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radio_test` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`test` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radio_test`
--

LOCK TABLES `radio_test` WRITE;
/*!40000 ALTER TABLE `radio_test` DISABLE KEYS */;
INSERT INTO `radio_test` VALUES
(230,'Panoramique dentaire'),
(231,'cone beam maxillaire'),
(232,'cone beam mandibulaire'),
(233,'dentascan');
/*!40000 ALTER TABLE `radio_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receptionniste`
--

DROP TABLE IF EXISTS `receptionniste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receptionniste` (
  `id` int(11) NOT NULL,
  `title` varchar(95) DEFAULT NULL,
  `company` varchar(195) DEFAULT NULL,
  `personOpeningAccount` varchar(195) NOT NULL,
  `dateOpened` date NOT NULL,
  `taxRateArea` varchar(255) DEFAULT NULL,
  `numProf` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receptionniste`
--

LOCK TABLES `receptionniste` WRITE;
/*!40000 ALTER TABLE `receptionniste` DISABLE KEYS */;
INSERT INTO `receptionniste` VALUES
(29,NULL,NULL,'admin','2023-02-04',NULL,NULL),
(43,NULL,NULL,'kbmadmin','2024-05-16',NULL,NULL);
/*!40000 ALTER TABLE `receptionniste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registered_prescription`
--

DROP TABLE IF EXISTS `registered_prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registered_prescription` (
  `id` int(11) NOT NULL,
  `consultation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_25C8FF9462FF6CDF` (`consultation_id`),
  FOREIGN KEY (`consultation_id`) REFERENCES`consultation` (`id`),
  FOREIGN KEY (`id`) REFERENCES`prescription` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registered_prescription`
--

LOCK TABLES `registered_prescription` WRITE;
/*!40000 ALTER TABLE `registered_prescription` DISABLE KEYS */;
/*!40000 ALTER TABLE `registered_prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminding_event`
--

DROP TABLE IF EXISTS `reminding_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reminding_event` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `body` longtext DEFAULT NULL,
  `state` varchar(100) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2C19CC96A76ED395` (`user_id`),
  KEY `IDX_2C19CC966B899279` (`patient_id`),
  FOREIGN KEY (`patient_id`) REFERENCES`patient` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`id`) REFERENCES`evenement` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminding_event`
--

LOCK TABLES `reminding_event` WRITE;
/*!40000 ALTER TABLE `reminding_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminding_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result_test`
--

DROP TABLE IF EXISTS `result_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `result_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picturePath` varchar(255) DEFAULT NULL,
  `pictureName` varchar(255) DEFAULT NULL,
  `visit_test_id` int(11) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4844654248D4009E` (`visit_test_id`),
  FOREIGN KEY (`visit_test_id`) REFERENCES`visit_test` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result_test`
--

LOCK TABLES `result_test` WRITE;
/*!40000 ALTER TABLE `result_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `result_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sample`
--

DROP TABLE IF EXISTS `sample`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sample` (
  `id` int(11) NOT NULL,
  `dailyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sample`
--

LOCK TABLES `sample` WRITE;
/*!40000 ALTER TABLE `sample` DISABLE KEYS */;
/*!40000 ALTER TABLE `sample` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_created_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `updateDate` date DEFAULT NULL,
  `responsible` varchar(195) DEFAULT NULL,
  `currentDailyId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E19D9AD2F987D8A8` (`user_created_id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_hospital_center`
--

DROP TABLE IF EXISTS `service_hospital_center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_hospital_center` (
  `service_id` int(11) NOT NULL,
  `hospital_center_id` int(11) NOT NULL,
  PRIMARY KEY (`service_id`,`hospital_center_id`),
  KEY `IDX_BD902E93ED5CA9E6` (`service_id`),
  KEY `IDX_BD902E9394CF6872` (`hospital_center_id`),
  FOREIGN KEY (`hospital_center_id`) REFERENCES`hospital_center` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`service_id`) REFERENCES`service` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_hospital_center`
--

LOCK TABLES `service_hospital_center` WRITE;
/*!40000 ALTER TABLE `service_hospital_center` DISABLE KEYS */;
INSERT INTO `service_hospital_center` VALUES
(1,1),
(2,1),
(3,1),
(4,1),
(5,1),
(6,1),
(7,1),
(8,1),
(9,1),
(10,1),
(11,1),
(12,1),
(13,1),
(14,1),
(16,1),
(17,1),
(18,1),
(19,1),
(20,1),
(21,1),
(22,1),
(23,1),
(24,1),
(25,1),
(26,1),
(31,1);
/*!40000 ALTER TABLE `service_hospital_center` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(55) DEFAULT NULL,
  `body` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
INSERT INTO `sms` VALUES
(1,'Prise de RDV','Bonjour _nom _prenom. Votre RDV est le _date à _heure. Si vous décidez de le reporter, veuillez nous appeler au _tel.'),
(2,'Modification de RDV','Bonjour _nom _prenom. Votre prochain RDV est le _date à _heure. Si vous décidez de le reporter, veuillez nous appeler au _tel.'),
(3,'Annulation de RDV','Bonjour _nom _prenom. Votre RDV du _date à _heure est annulé. Veuillez nous rappeler au _tel pour prendre un autre RDV.'),
(4,'Confirmation de RDV','Bonjour. Ceci est pour confirmer le rendez-vous de _nom _prenom le _date à _heure. Si vous décidez de le reporter, veuillez nous appeler au _tel.'),
(5,'Reporter RDV','Bonjour _nom _prenom. Nous vous informons que votre RDV est reporté pour le _date à _heure. Nous nous excusons pour le désagrément.'),
(6,'SMS Congé','Bonjour. Nous seront fermé pendant 10 jours.');
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_created_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `updateDate` date DEFAULT NULL,
  `next_id` int(11) DEFAULT NULL,
  `previous_id` int(11) DEFAULT NULL,
  `bg_color` varchar(255) DEFAULT NULL,
  `fg_color` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_7B00651CAA23F6C8` (`next_id`),
  UNIQUE KEY `UNIQ_7B00651C2DE62210` (`previous_id`),
  KEY `IDX_7B00651CF987D8A8` (`user_created_id`),
  FOREIGN KEY (`previous_id`) REFERENCES`status` (`id`),
  FOREIGN KEY (`next_id`) REFERENCES`status` (`id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sterilization`
--

DROP TABLE IF EXISTS `sterilization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sterilization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_created_id` int(11) NOT NULL,
  `material` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `date` datetime DEFAULT NULL,
  `dateStart` datetime DEFAULT NULL,
  `dateEnd` datetime DEFAULT NULL,
  `temperature` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_704C84A8F987D8A8` (`user_created_id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sterilization`
--

LOCK TABLES `sterilization` WRITE;
/*!40000 ALTER TABLE `sterilization` DISABLE KEYS */;
/*!40000 ALTER TABLE `sterilization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `quality` varchar(250) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `town` varchar(155) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `phone` varchar(55) DEFAULT NULL,
  `emergency_phone` varchar(55) DEFAULT NULL,
  `fix` varchar(55) DEFAULT NULL,
  `fax` varchar(55) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `visible` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_created_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `family` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `code` varchar(55) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `availability` tinyint(1) DEFAULT NULL,
  `updateDate` datetime DEFAULT NULL,
  `discr` varchar(255) NOT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D87F7E0CF987D8A8` (`user_created_id`),
  KEY `IDX_D87F7E0CED5CA9E6` (`service_id`),
  FOREIGN KEY (`service_id`) REFERENCES`service` (`id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread`
--

DROP TABLE IF EXISTS `thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thread` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `is_spam` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_31204C83B03A8386` (`created_by_id`),
  FOREIGN KEY (`created_by_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread`
--

LOCK TABLES `thread` WRITE;
/*!40000 ALTER TABLE `thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread_metadata`
--

DROP TABLE IF EXISTS `thread_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thread_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) DEFAULT NULL,
  `participant_id` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `last_participant_message_date` datetime DEFAULT NULL,
  `last_message_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_40A577C8E2904019` (`thread_id`),
  KEY `IDX_40A577C89D1C3019` (`participant_id`),
  FOREIGN KEY (`participant_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`thread_id`) REFERENCES`thread` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread_metadata`
--

LOCK TABLES `thread_metadata` WRITE;
/*!40000 ALTER TABLE `thread_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `thread_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `udc`
--

DROP TABLE IF EXISTS `udc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `udc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code1` varchar(55) DEFAULT NULL,
  `code2` varchar(55) DEFAULT NULL,
  `value` longtext DEFAULT NULL,
  `description1` longtext DEFAULT NULL,
  `description2` longtext DEFAULT NULL,
  `description3` longtext DEFAULT NULL,
  `description4` longtext DEFAULT NULL,
  `description5` longtext DEFAULT NULL,
  `description6` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1305 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `udc`
--

LOCK TABLES `udc` WRITE;
/*!40000 ALTER TABLE `udc` DISABLE KEYS */;
INSERT INTO `udc` VALUES
(1,'01','01','0','Règlement','0','0','Règlement','','#E15055'),
(2,'054','02','192.168.1.58','Adresse PACS',NULL,NULL,NULL,NULL,NULL),
(3,'02','03','DA','Devise',NULL,NULL,NULL,NULL,NULL),
(4,'02','04','50','Pourcentage chiffre d\'affaire',NULL,NULL,NULL,NULL,NULL),
(5,'02','05','100','Pourcentage à soustraire (consommable)',NULL,NULL,NULL,NULL,NULL),
(6,'02','06','50','Pourcentage à soustraire (Implant/Prothèses)',NULL,NULL,NULL,NULL,NULL),
(1294,'045','01294','0','Durée maximal attente','12','42',NULL,NULL,NULL),
(1295,'046','01295','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:300px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:10px 10px; border:0.5px solid; padding:2px; width:250px\"> <tbody> <tr> <td> <p><strong><strong><span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">&nbsp; &nbsp;<br /> &nbsp; &nbsp;Paris, </span></span></strong></strong><span style=\"font-family:Comic Sans MS,cursive\">Le _date</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;N&deg; de Dossier - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_id</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;Patient - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_nom _prenom</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;&Acirc;ge&nbsp; - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_age</span><strong><span style=\"font-family:Comic Sans MS,cursive\">&nbsp;</span></strong></p> </td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table>  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> <tr> <td style=\"text-align:center\"><strong>O R D O N N A N C E</strong></td> </tr> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> </tbody> </table>','Entête ordonnance','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1296,'047','01296','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:300px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:10px 10px; border:0.5px solid; padding:2px; width:250px\"> <tbody> <tr> <td> <p><strong><strong><span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">&nbsp; &nbsp;<br /> &nbsp; &nbsp;Paris, </span></span></strong></strong><span style=\"font-family:Comic Sans MS,cursive\">Le _date</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;N&deg; de Dossier - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_id</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;Patient - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_nom _prenom</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;&Acirc;ge&nbsp; - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_age</span><strong><span style=\"font-family:Comic Sans MS,cursive\">&nbsp;</span></strong></p> </td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table>  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> <tr> <td style=\"text-align:center\"><strong>C O M P T E - R E N D U </strong></td> </tr> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> </tbody> </table>','Entête compte-rendu','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1297,'048','01297','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:300px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:10px 10px; border:0.5px solid; padding:2px; width:250px\"> <tbody> <tr> <td> <p><strong><strong><span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">&nbsp; &nbsp;<br /> &nbsp; &nbsp;Paris, </span></span></strong></strong><span style=\"font-family:Comic Sans MS,cursive\">Le _date</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;N&deg; de Dossier - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_id</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;Patient - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_nom _prenom</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;&Acirc;ge&nbsp; - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_age</span><strong><span style=\"font-family:Comic Sans MS,cursive\">&nbsp;</span></strong></p> </td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table>  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> <tr> <td style=\"text-align:center\"><strong>C E R T I F I C A T &nbsp; &nbsp; M E D I C A L</strong></td> </tr> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> </tbody> </table>','Entête certificat','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1298,'049','01298','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:300px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:10px 10px; border:0.5px solid; padding:2px; width:250px\"> <tbody> <tr> <td> <p><strong><strong><span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">&nbsp; &nbsp;<br /> &nbsp; &nbsp;Paris, </span></span></strong></strong><span style=\"font-family:Comic Sans MS,cursive\">Le _date</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;N&deg; de Dossier - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_id</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;Patient - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_nom _prenom</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;&Acirc;ge&nbsp; - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_age</span><strong><span style=\"font-family:Comic Sans MS,cursive\">&nbsp;</span></strong></p> </td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table>  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> <tr> <td style=\"text-align:center\"><strong>L E T T R E &nbsp; &nbsp; D&#39; O R I E N T A T I O N </strong></td> </tr> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> </tbody> </table>','Entête lettre d\'orientation','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1299,'050','01299','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:300px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:10px 10px; border:0.5px solid; padding:2px; width:250px\"> <tbody> <tr> <td> <p><strong><strong><span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">&nbsp; &nbsp;<br /> &nbsp; &nbsp;Paris, </span></span></strong></strong><span style=\"font-family:Comic Sans MS,cursive\">Le _date</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;N&deg; de Dossier - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_id</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;Patient - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_nom _prenom</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;&Acirc;ge&nbsp; - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_age</span><strong><span style=\"font-family:Comic Sans MS,cursive\">&nbsp;</span></strong></p> </td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table>  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> <tr> <td style=\"text-align:center\"><strong>D E M A N D E &nbsp; &nbsp; B I O L O G I Q U E</strong></td> </tr> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> </tbody> </table>','Entête demande examen biologique','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1300,'051','01300','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:300px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:30px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:10px 10px; border:0.5px solid; padding:2px; width:250px\"> <tbody> <tr> <td> <p><strong><strong><span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">&nbsp; &nbsp;<br /> &nbsp; &nbsp;Paris, </span></span></strong></strong><span style=\"font-family:Comic Sans MS,cursive\">Le _date</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;N&deg; de Dossier - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_id</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;Patient - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_nom _prenom</span><br /> <strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">&nbsp; &nbsp;&Acirc;ge&nbsp; - </span></strong><span style=\"font-family:&quot;Comic Sans MS&quot;,cursive\">_age</span><strong><span style=\"font-family:Comic Sans MS,cursive\">&nbsp;</span></strong></p> </td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table>  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> <tr> <td style=\"text-align:center\"><strong>D E M A N D E &nbsp; &nbsp; R A D I O L O G I Q U E</strong></td> </tr> <tr> <td style=\"text-align:center\"> <hr /></td> </tr> </tbody> </table>','Entête demande examen radiologique','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1301,'053','01301','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\"> <tbody> <tr> <td> <p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">DEVIS _devisId</span></span></strong></p> <strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le _date&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - _id<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - _nom _prenom<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - _age&nbsp;<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Devis valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table> &nbsp;<br /> <br /> &nbsp; <table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\"> <tbody> <tr> <td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td> <td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td> <td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td> <td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td> <td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td> </tr> </tbody> </table>','Entête devis','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1302,'055','01302','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\"> <tbody> <tr> <td style=\"width:350px\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:330px\"> <tbody> <tr> <td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img alt=\"\" src=\"/mydental/web/uploads/kbmdent.png\" style=\"height:60px; width:230px\" /></td> </tr> <tr> <td style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\">Clinique Dentaire<br /> Adresse<br /> <span style=\"font-size:12px\">Email&nbsp;:&nbsp;<br /> T&eacute;l:&nbsp;</span></span></td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"width:150px\"> <tbody> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> <td> <table cellpadding=\"0\" cellspacing=\"0\" style=\"border-radius:50px 50px; border:1px solid; padding:5px; width:290px\"> <tbody> <tr> <td> <p style=\"text-align:center\"><strong><span style=\"font-size:26px\"><span style=\"font-family:Comic Sans MS,cursive\">FACTURE _invoiceId</span></span></strong></p> <strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"font-size:14px\"><span style=\"font-family:Comic Sans MS,cursive\">Paris, </span></span></strong><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Le _date&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;N&deg; de Dossier - _id<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Patient - _nom _prenom<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&Acirc;ge&nbsp; - _age&nbsp;<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Facture valable 2 mois&nbsp; &nbsp;</strong></span></span><strong>&nbsp;</strong></td> </tr> <tr> <td>&nbsp;</td> </tr> </tbody> </table> </td> </tr> </tbody> </table> &nbsp;<br /> <br /> &nbsp; <table border=\"1\" cellpadding=\"10\" cellspacing=\"1\" style=\"background-color:#f3f9f9; min-width:800px; width:100%\"> <tbody> <tr> <td style=\"width:38%\"><span style=\"font-family:Comic Sans MS,cursive\">Acte</span></td> <td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix unitaire</span></td> <td style=\"text-align:center; width:16%\"><span style=\"font-family:Comic Sans MS,cursive\">Remise</span></td> <td style=\"text-align:center; width:10%\"><span style=\"font-family:Comic Sans MS,cursive\">Qt&eacute;</span></td> <td style=\"text-align:center; width:20%\"><span style=\"font-family:Comic Sans MS,cursive\">Prix HT</span></td> </tr> </tbody> </table>','Entête facture','12','42',NULL,'font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#000000',NULL),
(1303,'01','01303','7000','obturation mono bioceramique','12','23','obturation mono bioceramique','','#E15055'),
(1304,'01','01304','9000','obturation pluri  bioceramique','12','23','obturation pluri  bioceramique','','#E15055');
/*!40000 ALTER TABLE `udc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `urological_surgery_consultation`
--

DROP TABLE IF EXISTS `urological_surgery_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `urological_surgery_consultation` (
  `id` int(11) NOT NULL,
  `medical_signs` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id`) REFERENCES`visit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urological_surgery_consultation`
--

LOCK TABLES `urological_surgery_consultation` WRITE;
/*!40000 ALTER TABLE `urological_surgery_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `urological_surgery_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `username_canonical` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  `picturePath` varchar(255) DEFAULT NULL,
  `pictureName` varchar(255) DEFAULT NULL,
  `lastName` varchar(150) NOT NULL,
  `firstName` varchar(150) NOT NULL,
  `birthDate` date DEFAULT NULL,
  `birthPlace` varchar(155) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gender` varchar(70) DEFAULT NULL,
  `phone` varchar(35) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `emailCanonical` varchar(255) DEFAULT NULL,
  `discr` varchar(255) NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `first_login_today` datetime DEFAULT NULL,
  `specialisation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D64992FC23A8` (`username_canonical`),
  KEY `IDX_8D93D6495627D44C` (`specialisation_id`),
  FOREIGN KEY (`specialisation_id`) REFERENCES`service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES
(21,'radio','radio',1,'ae38i296m6g48k08cws4wowk0sws004','keRvZgSdzvSt2FIP6asumkPj2YX9MbeA2NVJzlyagY9xUYIBHhqbFGNNLoMMyncCsWYW6VDMEhk5W/D0ntQqOQ==','2024-11-04 09:58:15',0,0,NULL,NULL,NULL,'a:1:{i:0;s:11:\"ROLE_DOCTOR\";}',0,NULL,NULL,NULL,'RADIO','User',NULL,'Paris',NULL,'Homme',NULL,NULL,NULL,'Doctor','2024-11-04 10:11:47','2024-11-04 09:58:15',12),
(22,'kbmadmin','kbmadmin',1,'bykyrtgyzogg0c0g04w4c8w08wo0osg','JNLAOBuM+1nmrZtiImi3RRmpDSZuvExPYRcw6zOLdkjgfj/DHzJOVMlerEr3ImITaJ5oyZRe73Y1i/DOHZ8wBQ==','2024-05-16 11:23:16',0,0,NULL,NULL,NULL,'a:1:{i:0;s:16:\"ROLE_SUPER_ADMIN\";}',0,NULL,'uploads/users','b6f196f1751d04f050cde67aa59a9d1e.jpeg','KBM','Technologie','2015-09-06','Paris',NULL,'Homme','021400555',NULL,NULL,'Doctor','2024-05-16 11:31:24','2024-05-16 11:23:16',12),
(23,'admin','admin',1,'pag4yrur880kwo8coosgkscwskc4wsw','w1+KMPvBjLLQjIOPNMbLtbH2yCc407X7rCACoThBjfh9GGa/1x73EDoYbYb5FmUyCduFdCT+H2RUbVvvbLr6sw==','2024-11-05 12:04:26',0,0,NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_ADMIN\";}',0,NULL,NULL,NULL,'ADMIN','ADMIN',NULL,'Poitiers',NULL,'Homme',NULL,NULL,NULL,'Doctor','2024-10-30 16:06:46','2024-11-05 12:04:26',12),
(24,'brobert','brobert',1,'4okxohlbzpmo888ow4wckw0004cgk84','haIjj5eouNQodBq2dDbotVOWCdNry6jw6H7cXFTbxEk4LTnEzTFqBcZdw8x3u3I10uO7d1pjUpsort3fxP6R+Q==','2024-11-05 03:02:43',0,0,NULL,NULL,NULL,'a:1:{i:0;s:11:\"ROLE_DOCTOR\";}',0,NULL,NULL,NULL,'ROBERT','Brice','1993-05-14','Niort',NULL,'Homme',NULL,NULL,NULL,'Doctor','2024-11-05 03:02:54','2024-11-05 00:58:18',12),
(41,'nlacroix','nlacroix',1,'b87nm1nqpt4ow8gsw40s4c4gsks08cg','XDOPxvqm7zvAge9g5kkLn2rI8Ga1DkiXk5Gg6pJSMLQG9cFbECQUGG+bCW6CrS+mVoMmPsRMOnkNXgVhmZYQ0A==','2024-11-02 19:40:21',0,0,NULL,NULL,NULL,'a:1:{i:0;s:11:\"ROLE_DOCTOR\";}',0,NULL,NULL,NULL,'LACROIX','Nadia','1998-06-06','New City',NULL,'Homme',NULL,NULL,NULL,'Doctor','2024-11-02 19:42:23','2024-11-02 19:40:21',12),
(42,'llopez','llopez',1,'a2d12edw8s0ss884os4o8c00s0o0gkk','yz2j7HsxvJ6xQjvOq9Xd3yJ+Fi3zzDmrD1ul//lBCRDz+S1IXcEFBsKyGN8EVInRVPsci35Bj1R6YlKSuBHApQ==','2024-11-05 10:54:52',0,0,NULL,NULL,NULL,'a:1:{i:0;s:11:\"ROLE_DOCTOR\";}',0,NULL,NULL,NULL,'LOPEZ','Lea','1999-07-04','Nantes',NULL,'Femme','0549980420',NULL,NULL,'Doctor','2024-11-04 17:49:30','2024-11-05 10:23:22',12),
(43,'reception2','reception2',1,'ifmjh6kjzxw88kk088s4kg4c0cos88k','EMX68xQUptNj9tTBgbjLbHYCWHocl89CTfWJIQwofWHVK0Be1qiKrOmhW48aeffOb/N6ccTzPX5hDyiXv9UlDQ==','2024-05-30 20:03:31',0,0,NULL,NULL,NULL,'a:1:{i:0;s:19:\"ROLE_RECEPTIONNISTE\";}',0,NULL,NULL,NULL,'RECEPTION','2','2000-05-14',NULL,NULL,'Femme',NULL,NULL,NULL,'Receptionniste','2024-05-30 21:39:46','2024-05-30 20:03:31',4);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_event`
--

DROP TABLE IF EXISTS `user_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_event` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D96CF1FFA76ED395` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`id`) REFERENCES`evenement` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_event`
--

LOCK TABLES `user_event` WRITE;
/*!40000 ALTER TABLE `user_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit`
--

DROP TABLE IF EXISTS `visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `current_location_id` int(11) NOT NULL,
  `current_hospital_center_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `user_created_id` int(11) NOT NULL,
  `visit_created_id` int(11) DEFAULT NULL,
  `arrivalDate` datetime DEFAULT NULL,
  `currentLocalTimeAssignment` datetime DEFAULT NULL,
  `status` varchar(80) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `discr` varchar(255) NOT NULL,
  `user_activated_id` int(11) DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `starting_price` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `remaining_amount` double DEFAULT NULL,
  `first_payment` double DEFAULT NULL,
  `second_payment` double DEFAULT NULL,
  `payment_method` longtext DEFAULT NULL,
  `payment_note` longtext DEFAULT NULL,
  `notice` longtext DEFAULT NULL,
  `act` varchar(200) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `next_visit_note` varchar(200) DEFAULT NULL,
  `bg_Color` longtext DEFAULT NULL,
  `cashed_user_id` int(11) DEFAULT NULL,
  `invoiced` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_437EE939B8998A57` (`current_location_id`),
  KEY `IDX_437EE93958972FF9` (`current_hospital_center_id`),
  KEY `IDX_437EE9396B899279` (`patient_id`),
  KEY `IDX_437EE939F987D8A8` (`user_created_id`),
  KEY `IDX_437EE9393A086057` (`visit_created_id`),
  KEY `IDX_437EE93925616CF4` (`user_activated_id`),
  KEY `IDX_437EE939CBE4068A` (`cashed_user_id`),
  FOREIGN KEY (`user_activated_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`visit_created_id`) REFERENCES`visit` (`id`),
  FOREIGN KEY (`current_hospital_center_id`) REFERENCES`hospital_center` (`id`),
  FOREIGN KEY (`patient_id`) REFERENCES`patient` (`id`),
  FOREIGN KEY (`current_location_id`) REFERENCES`service` (`id`),
  FOREIGN KEY (`cashed_user_id`) REFERENCES`user` (`id`),
  FOREIGN KEY (`user_created_id`) REFERENCES`user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32724 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit`
--

LOCK TABLES `visit` WRITE;
/*!40000 ALTER TABLE `visit` DISABLE KEYS */;
INSERT INTO `visit` VALUES
(2,12,1,2,24,NULL,'2023-02-03 23:34:44','2023-02-03 23:34:44','A revoir',0,NULL,1,'OrthodonticConsultation',24,'2023-02-03 23:34:00','2023-02-03 23:41:46',0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),
(3,12,1,3,24,NULL,'2023-02-03 23:46:01','2023-02-03 23:46:01','A revoir',0,NULL,1,'OrthodonticConsultation',24,'2023-02-03 23:46:00','2023-02-03 23:47:43',0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),
(32720,12,1,11738,29,NULL,'2024-11-05 11:46:22','2024-11-05 11:46:22','Actif',0,'Consultation',1,'OrthodonticConsultation',27,'2024-11-05 11:58:29',NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'6',NULL,'#E15055',NULL,0),
(32721,12,1,11756,29,NULL,'2024-11-05 11:54:48','2024-11-05 11:54:48','Actif',0,'Consultation',1,'OrthodonticConsultation',38,'2024-11-05 12:01:26',NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'6',NULL,'#E15055',NULL,0),
(32722,12,1,11784,29,NULL,'2024-11-05 11:55:55','2024-11-05 11:55:55','En attente',0,'Consultation',1,'OrthodonticConsultation',NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'6',NULL,'#E15055',NULL,0),
(32723,12,1,5316,29,NULL,'2024-11-05 12:01:44','2024-11-05 12:01:44','En attente',0,'Consultation',1,'OrthodonticConsultation',NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'6',NULL,'#E15055',NULL,0);
/*!40000 ALTER TABLE `visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_test`
--

DROP TABLE IF EXISTS `visit_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visit_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `testRequested` tinyint(1) NOT NULL,
  `testChecked` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_72783CE75FA0FF2` (`visit_id`),
  KEY `IDX_72783CE1E5D0459` (`test_id`),
  FOREIGN KEY (`test_id`) REFERENCES`test` (`id`),
  FOREIGN KEY (`visit_id`) REFERENCES`visit` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_test`
--

LOCK TABLES `visit_test` WRITE;
/*!40000 ALTER TABLE `visit_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `visit_test` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2024-12-07 21:54:09
