import sqlite3
import os

# --- CONFIGURATION ---
DB_FILE = './BD_sqlite/dental_data.db' # Le même chemin que le script précédent
# ---------------------

def describe_database():
    if not os.path.exists(DB_FILE):
        print(f"❌ Erreur : La base de données {DB_FILE} n'existe pas.")
        return

    print(f"🔍 ANALYSE DE LA BASE : {DB_FILE}\n")

    conn = sqlite3.connect(DB_FILE)
    # Cette ligne est magique : elle permet d'accéder aux colonnes par leur nom
    conn.row_factory = sqlite3.Row 
    cursor = conn.cursor()

    # 1. Récupérer la liste de toutes les tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
    tables = cursor.fetchall()

    if not tables:
        print("⚠️ Aucune table trouvée dans la base.")
        return

    count_tables = len(tables)
    print(f"Nombre de tables trouvées : {count_tables}\n")

    # 2. Boucler sur chaque table
    for table in tables:
        table_name = table['name']
        print(f"📦 TABLE : {table_name}")
        print("=" * 50)

        try:
            # Récupérer 1 seule ligne
            cursor.execute(f"SELECT * FROM {table_name} LIMIT 1")
            row = cursor.fetchone()

            if row:
                # Afficher chaque colonne et sa valeur
                for col_name in row.keys():
                    value = row[col_name]
                    # On tronque les textes trop longs pour l'affichage (ex: mot de passe hashé ou gros texte)
                    val_str = str(value)
                    if len(val_str) > 80:
                        val_str = val_str[:77] + "..."
                    
                    print(f"  • {col_name:<20} : {val_str}")
            else:
                print("  (⚠️ Table vide, aucune donnée)")
        
        except sqlite3.Error as e:
            print(f"  ❌ Erreur de lecture : {e}")
        
        print("\n") # Saut de ligne entre les tables

    conn.close()

if __name__ == "__main__":
    describe_database()